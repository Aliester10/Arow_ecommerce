<div class="bg-white rounded-lg sm:rounded-xl shadow-sm border border-gray-100 sidebar-container z-30 flex flex-col md:h-96">
    
    <div class="px-3 sm:px-4 py-2 sm:py-3 border-b border-gray-100 rounded-t-lg sm:rounded-t-xl" style="background-color:#F7931E">
        <div class="flex items-center text-white font-semibold text-xs sm:text-sm gap-2">
            <i class="fas fa-list text-sm"></i>
            <span>Kategori Produk</span>
        </div>
    </div>

    
    <ul class="divide-y divide-gray-50 pb-2 flex-1 overflow-y-auto">
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
            <li class="group" data-category="<?php echo e($category->id_kategori); ?>" style="position: static;">
                <a href="<?php echo e(route('products.index', ['category' => $category->nama_kategori])); ?>"
                   class="flex items-center justify-between px-3 sm:px-4 py-2 sm:py-3 text-xs sm:text-sm text-gray-700 hover:bg-orange-50 hover:text-orange-600 transition">
                    <span class="flex items-center gap-2 min-w-0">
                        <?php
                            $iconPath = $category->icon_kategori;
                            $isSvg = $iconPath ? (strtolower(pathinfo($iconPath, PATHINFO_EXTENSION)) === 'svg') : false;

                            $iconCandidates = $iconPath ? [
                                $iconPath,
                                'storage/' . ltrim($iconPath, '/'),
                                'storage/images/' . ltrim($iconPath, '/'),
                            ] : [];

                            $resolvedIconPath = null;
                            $resolvedIconFullPath = null;

                            foreach ($iconCandidates as $candidate) {
                                $full = public_path($candidate);
                                if (file_exists($full)) {
                                    $resolvedIconPath = $candidate;
                                    $resolvedIconFullPath = $full;
                                    break;
                                }
                            }

                            $iconExists = (bool) $resolvedIconFullPath;
                        ?>

                        <?php if($iconExists && $isSvg): ?>
                            <?php
                                $svg = file_get_contents($resolvedIconFullPath);
                                $svg = preg_replace('/<svg(\\s+)/i', '<svg$1style="width:20px;height:20px;" fill="currentColor" stroke="currentColor" ', $svg, 1);

                                $svg = preg_replace('/\sfill="(?!none)[^"]*"/i', ' fill="currentColor"', $svg);
                                $svg = preg_replace('/\sstroke="(?!none)[^"]*"/i', ' stroke="currentColor"', $svg);

                                $svg = preg_replace('/fill\s*:\s*(?!none)[^;\"\']+/i', 'fill:currentColor', $svg);
                                $svg = preg_replace('/stroke\s*:\s*(?!none)[^;\"\']+/i', 'stroke:currentColor', $svg);
                            ?>
                            <span class="flex-shrink-0" style="color:#F7931E" aria-hidden="true"><?php echo $svg; ?></span>
                        <?php elseif($iconExists): ?>
                            <img src="<?php echo e(asset($resolvedIconPath)); ?>" alt="<?php echo e($category->nama_kategori); ?>" class="w-5 h-5 object-contain flex-shrink-0">
                        <?php else: ?>
                            <span class="w-5 h-5 flex items-center justify-center flex-shrink-0" style="color:#F7931E">
                                <i class="fas fa-tag"></i>
                            </span>
                        <?php endif; ?>
                        <span class="truncate"><?php echo e($category->nama_kategori); ?></span>
                    </span>
                </a>

                
                <?php if($category->subkategori->count() > 0): ?>
                    
                    <div class="hidden md:block absolute bg-white rounded-xl shadow-xl border border-gray-100 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 overflow-hidden" 
                         style="top: 0; left: calc(var(--sidebar-width, 33.333333%) + var(--sidebar-gap, 1.5rem)); right: 0; height: var(--mega-height, 24rem); z-index: 50;">
                        <div class="p-6 h-full overflow-y-auto">
                            <div class="flex items-center justify-between mb-4 border-b border-gray-100 pb-2">
                                <h4 class="font-bold text-gray-800 text-lg">
                                    <?php echo e($category->nama_kategori); ?>

                                </h4>
                                <a href="<?php echo e(route('products.index', ['category' => $category->nama_kategori])); ?>" class="text-xs text-orange-600 hover:underline">
                                    Lihat Semua
                                </a>
                            </div>

                            <div class="grid grid-cols-3 gap-6">
                                <?php $__currentLoopData = $category->subkategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <a href="<?php echo e(route('products.index', ['category' => $sub->nama_subkategori])); ?>"
                                           class="block text-sm font-semibold text-gray-700 hover:text-orange-600 transition-colors duration-200 py-1">
                                            <?php echo e($sub->nama_subkategori); ?>

                                        </a>

                                        <?php if($sub->subSubkategori->count() > 0): ?>
                                            <div class="mt-1 space-y-1">
                                                <?php $__currentLoopData = $sub->subSubkategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(route('products.index', ['category' => $subSub->nama_sub_subkategori])); ?>"
                                                       class="block text-xs text-gray-500 hover:text-orange-600 hover:translate-x-1 transition-transform duration-200">
                                                        <?php echo e($subSub->nama_sub_subkategori); ?>

                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li class="px-4 py-6 text-center text-sm text-gray-500">
                <i class="fas fa-inbox text-gray-300 text-xl mb-2 block"></i>
                Tidak ada kategori
            </li>
        <?php endif; ?>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\aro\aro_ecommerce\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>