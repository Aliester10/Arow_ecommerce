<?php $__env->startSection('content'); ?>
<style>
@media (min-width: 768px) {
    .products-row-layout { --sidebar-width: 30%; }
    .products-row-layout .products-sidebar { flex: 0 0 var(--sidebar-width); max-width: var(--sidebar-width); }
    .products-row-layout .products-content { flex: 1 1 0; min-width: 0; }
}
</style>
<div class="container mx-auto px-2 sm:px-4">
    <div class="products-row-layout flex flex-col md:flex-row gap-4 md:gap-6 relative" style="--sidebar-width: 30%; --sidebar-gap: 1.5rem;">
        <!-- Sidebar -->
        <aside class="products-sidebar w-full hidden md:block">
            <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </aside>

        <!-- Main Content -->
        <div class="products-content w-full">
            <!-- Breadcrumbs / Title -->
            <div class="mb-4 md:mb-6 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                <h1 class="text-lg sm:text-xl font-bold text-gray-800">
                    <?php if(request('category')): ?>
                        Kategori: <?php echo e(request('category')); ?>

                    <?php elseif(request('search')): ?>
                        Hasil Pencarian: "<?php echo e(request('search')); ?>"
                    <?php else: ?>
                        Semua Produk
                    <?php endif; ?>
                </h1>
                <div class="text-xs sm:text-sm text-gray-500">
                    Menampilkan <?php echo e($products->firstItem() ?? 0); ?>-<?php echo e($products->lastItem() ?? 0); ?> dari <?php echo e($products->total()); ?> produk
                </div>
            </div>

            <!-- Products Grid -->
            <?php if($products->count() > 0): ?>
                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 sm:gap-4 md:gap-6">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition group overflow-hidden" data-skeleton-container>
                            <div class="relative h-32 sm:h-40 md:h-48 bg-gray-100 overflow-hidden">
                                <!-- Skeleton Loading -->
                                <div data-skeleton class="skeleton-shimmer w-full h-full flex items-center justify-center bg-gray-200 absolute inset-0 z-10"></div>

                                <!-- Product Image Placeholder -->
                                <?php if($product->gambar_produk && file_exists(public_path('storage/images/produk/' . $product->gambar_produk))): ?>
                                    <img src="<?php echo e(asset('storage/images/produk/' . $product->gambar_produk)); ?>"
                                         alt="<?php echo e($product->nama_produk); ?>"
                                         data-skeleton-image
                                         class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                                         style="display: none;">
                                <?php else: ?>
                                    <div data-fallback-image class="w-full h-full flex items-center justify-center text-gray-300 bg-gray-50 absolute inset-0 z-0" style="display: none;">
                                        <img src="<?php echo e(asset('hitam-putih.svg')); ?>" 
                                             alt="No Image" 
                                             class="w-12 h-12 sm:w-16 sm:h-16 object-contain opacity-60">
                                    </div>
                                    <img src="<?php echo e(asset('hitam-putih.svg')); ?>" 
                                         alt="<?php echo e($product->nama_produk); ?>"
                                         data-skeleton-image
                                         class="w-full h-full object-contain p-4 sm:p-6 bg-white"
                                         style="display: block;">
                                <?php endif; ?>
                                
                                <!-- Overlay Actions -->
                                <div class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300 gap-1 sm:gap-2">
                                    <a href="<?php echo e(route('products.show', $product->id_produk)); ?>" class="p-1 sm:p-2 bg-white rounded-full text-gray-800 hover:text-orange-600 shadow-lg transform translate-y-4 group-hover:translate-y-0 transition duration-300 text-xs sm:text-base">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <form action="<?php echo e(route('cart.add', $product->id_produk)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="p-1 sm:p-2 bg-orange-600 rounded-full text-white hover:bg-orange-700 shadow-lg transform translate-y-4 group-hover:translate-y-0 transition duration-300 delay-75 text-xs sm:text-base">
                                            <i class="fas fa-shopping-cart"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <div class="p-2 sm:p-4">
                                <div class="text-[10px] sm:text-xs text-gray-500 mb-1 line-clamp-1"><?php echo e($product->brand->nama_brand ?? 'Brand'); ?></div>
                                <a href="<?php echo e(route('products.show', $product->id_produk)); ?>" class="block text-gray-800 font-medium text-xs sm:text-sm mb-2 hover:text-orange-600 line-clamp-2 min-h-[2em] sm:min-h-[2.5rem]">
                                    <?php echo e($product->nama_produk); ?>

                                </a>
                                <div class="font-bold text-orange-600 text-xs sm:text-sm">Rp <?php echo e(number_format($product->harga_produk, 0, ',', '.')); ?></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="mt-6 md:mt-8">
                    <?php echo e($products->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-8 sm:py-12 bg-white rounded-lg shadow-sm">
                    <i class="fas fa-search text-gray-300 text-5xl sm:text-6xl mb-2 sm:mb-4"></i>
                    <h3 class="text-base sm:text-lg font-medium text-gray-600">Tidak ada produk ditemukan</h3>
                    <p class="text-gray-500 mt-2 text-sm sm:text-base">Coba kata kunci lain atau reset filter.</p>
                    <a href="<?php echo e(route('products.index')); ?>" class="inline-block mt-4 px-4 sm:px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition text-sm sm:text-base">Lihat Semua Produk</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aro\aro_ecommerce\resources\views/products/index.blade.php ENDPATH**/ ?>