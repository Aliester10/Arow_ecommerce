<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 md:p-8">
            <!-- Image Gallery -->
            <div class="space-y-4">
                <div class="aspect-square bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center border border-gray-200">
                    <!-- Main Image Placeholder -->
                    <?php if($product->gambar_produk && file_exists(public_path('storage/images/produk/' . $product->gambar_produk))): ?>
                        <img src="<?php echo e(asset('storage/images/produk/' . $product->gambar_produk)); ?>" 
                             alt="<?php echo e($product->nama_produk); ?>" 
                             class="w-full h-full object-contain p-4">
                    <?php else: ?>
                        <i class="fas fa-box text-6xl text-gray-300"></i>
                    <?php endif; ?>
                </div>
                <?php if($product->gambar_produk && file_exists(public_path('storage/images/produk/' . $product->gambar_produk))): ?>
                    <div class="flex gap-2">
                        <div class="w-20 h-20 bg-gray-50 rounded-md border border-gray-200 cursor-pointer hover:border-orange-500 transition overflow-hidden">
                            <img src="<?php echo e(asset('storage/images/produk/' . $product->gambar_produk)); ?>" 
                                 alt="<?php echo e($product->nama_produk); ?>" 
                                 class="w-full h-full object-contain p-2">
                        </div>
                    </div>
                <?php endif; ?>

                <div class="bg-white rounded-lg border border-gray-100 overflow-hidden">
                    <div class="flex border-b border-gray-100">
                        <button type="button" id="tabSpecBtn" class="flex-1 px-4 py-3 text-sm font-semibold text-orange-600 border-b-2 border-orange-600 bg-orange-50">
                            Spesifikasi Produk
                        </button>
                        <button type="button" id="tabReviewBtn" class="flex-1 px-4 py-3 text-sm font-semibold text-gray-600 hover:text-orange-600">
                            Ulasan
                        </button>
                    </div>

                    <div id="tabSpec" class="p-4">
                        <dl class="text-sm divide-y divide-gray-100">
                            <div class="grid grid-cols-3 gap-3 py-2">
                                <dt class="text-gray-500">NAMA</dt>
                                <dd class="col-span-2 font-medium text-gray-800"><?php echo e($product->nama_produk); ?></dd>
                            </div>

                            <div class="grid grid-cols-3 gap-3 py-2">
                                <dt class="text-gray-500">MEREK</dt>
                                <dd class="col-span-2 font-medium text-gray-800"><?php echo e($product->brand->nama_brand ?? '-'); ?></dd>
                            </div>

                            <div class="grid grid-cols-3 gap-3 py-2">
                                <dt class="text-gray-500">SKU</dt>
                                <dd class="col-span-2 font-medium text-gray-800"><?php echo e($product->sku_produk ?? '-'); ?></dd>
                            </div>

                            <div class="grid grid-cols-3 gap-3 py-2">
                                <dt class="text-gray-500">TYPE/COVER</dt>
                                <dd class="col-span-2 font-medium text-gray-800"><?php echo e($product->tipe_produk ?? '-'); ?></dd>
                            </div>

                            <div class="grid grid-cols-3 gap-3 py-2">
                                <dt class="text-gray-500">ASAL NEGARA</dt>
                                <dd class="col-span-2 font-medium text-gray-800"><?php echo e($product->asal_produk ?? '-'); ?></dd>
                            </div>

                            <div class="grid grid-cols-3 gap-3 py-2">
                                <dt class="text-gray-500">SUB KATEGORI</dt>
                                <dd class="col-span-2 font-medium text-gray-800"><?php echo e($product->subSubkategori->subkategori->nama_subkategori ?? '-'); ?></dd>
                            </div>

                            <div class="grid grid-cols-3 gap-3 py-2">
                                <dt class="text-gray-500">SUB SUB KATEGORI</dt>
                                <dd class="col-span-2 font-medium text-gray-800"><?php echo e($product->subSubkategori->nama_sub_subkategori ?? '-'); ?></dd>
                            </div>

                            <div class="grid grid-cols-3 gap-3 py-2">
                                <dt class="text-gray-500">DIMENSI</dt>
                                <dd class="col-span-2 font-medium text-gray-800"><?php echo e($product->dimensi_produk ?? '-'); ?></dd>
                            </div>
                        </dl>

                        <?php if($product->spesifikasi_produk): ?>
                            <div class="mt-4 pt-4 border-t border-gray-100">
                                <div class="text-sm font-semibold text-gray-800 mb-2">Spesifikasi</div>
                                <div class="text-sm text-gray-600 leading-relaxed whitespace-pre-line"><?php echo e($product->spesifikasi_produk); ?></div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div id="tabReview" class="p-4 hidden">
                        <?php if(session('success')): ?>
                            <div class="mb-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="space-y-4">
                            <?php if($product->ulasan->count() > 0): ?>
                                <?php $__currentLoopData = $product->ulasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="border border-gray-100 rounded-lg p-3">
                                        <div class="flex items-center justify-between">
                                            <div class="text-sm font-semibold text-gray-800"><?php echo e($review->user->nama_user ?? 'User'); ?></div>
                                            <div class="text-xs text-gray-400"><?php echo e(\Carbon\Carbon::parse($review->tanggal_ulasan)->format('d M Y')); ?></div>
                                        </div>
                                        <div class="mt-1 text-yellow-500 text-sm">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="<?php echo e($i <= (int) $review->rating_ulasan ? 'fas' : 'far'); ?> fa-star"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <?php if($review->komentar_ulasan): ?>
                                            <div class="mt-2 text-sm text-gray-600"><?php echo e($review->komentar_ulasan); ?></div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="text-sm text-gray-500">Belum ada ulasan.</div>
                            <?php endif; ?>

                            <div class="border-t border-gray-100 pt-4">
                                <?php if(auth()->guard()->check()): ?>
                                    <form action="<?php echo e(route('ulasan.store', $product->id_produk)); ?>" method="POST" class="space-y-3">
                                        <?php echo csrf_field(); ?>
                                        <div>
                                            <label class="block text-sm font-semibold text-gray-700 mb-1">Rating</label>
                                            <select name="rating_ulasan" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-orange-500" required>
                                                <option value="">Pilih rating</option>
                                                <option value="5">5</option>
                                                <option value="4">4</option>
                                                <option value="3">3</option>
                                                <option value="2">2</option>
                                                <option value="1">1</option>
                                            </select>
                                            <?php $__errorArgs = ['rating_ulasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-xs text-red-600 mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div>
                                            <label class="block text-sm font-semibold text-gray-700 mb-1">Komentar</label>
                                            <textarea name="komentar_ulasan" rows="3" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-orange-500" placeholder="Tulis ulasan..."></textarea>
                                            <?php $__errorArgs = ['komentar_ulasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-xs text-red-600 mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <button type="submit" class="w-full px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition text-sm font-semibold">
                                            Kirim Ulasan
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>" class="block w-full text-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition text-sm font-semibold">
                                        Login untuk memberi ulasan
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Product Info -->
            <div>
                <nav class="flex text-sm text-gray-500 mb-4" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="<?php echo e(route('home')); ?>" class="hover:text-orange-600">Home</a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <i class="fas fa-chevron-right text-xs mx-2"></i>
                                <a href="<?php echo e(route('products.index', ['category' => $product->subSubkategori->subkategori->kategori->nama_kategori ?? 'All'])); ?>" class="hover:text-orange-600"><?php echo e($product->subSubkategori->subkategori->kategori->nama_kategori ?? 'Kategori'); ?></a>
                            </div>
                        </li>
                        <li aria-current="page">
                            <div class="flex items-center">
                                <i class="fas fa-chevron-right text-xs mx-2"></i>
                                <span class="text-gray-400"><?php echo e(Str::limit($product->nama_produk, 20)); ?></span>
                            </div>
                        </li>
                    </ol>
                </nav>

                <h1 class="text-2xl md:text-3xl font-bold text-gray-900 mb-2"><?php echo e($product->nama_produk); ?></h1>
                
                <div class="flex items-center mb-4 space-x-4">
                    <div class="text-sm text-gray-500 border-r border-gray-300 pr-4">
                        Brand: <span class="text-orange-600 font-medium"><?php echo e($product->brand->nama_brand ?? 'N/A'); ?></span>
                    </div>
                    <div class="flex items-center">
                        <i class="fas fa-star text-yellow-400 text-sm"></i>
                        <span class="text-sm text-gray-600 ml-1 font-bold">4.8</span>
                        <span class="text-sm text-gray-400 ml-1">(12 Ulasan)</span>
                    </div>
                </div>

                <div class="text-3xl font-bold text-orange-600 mb-6">
                    Rp <?php echo e(number_format($product->harga_produk, 0, ',', '.')); ?>

                </div>

                <div class="mb-6">
                    <h3 class="text-sm font-bold text-gray-900 mb-2">Deskripsi Produk</h3>
                    <p class="text-gray-600 text-sm leading-relaxed">
                        <?php echo e($product->deskripsi_produk); ?>

                    </p>
                </div>

                <div class="border-t border-gray-100 pt-6">
                    <div class="flex items-center space-x-4 mb-6">
                        <div class="flex items-center border border-gray-300 rounded-lg">
                            <button type="button" class="px-3 py-2 text-gray-600 hover:bg-gray-100" onclick="decrementQty()">-</button>
                            <input type="number" id="quantity" value="1" min="1" max="<?php echo e($product->stok_produk); ?>" class="w-12 text-center text-sm focus:outline-none" readonly>
                            <button type="button" class="px-3 py-2 text-gray-600 hover:bg-gray-100" onclick="incrementQty()">+</button>
                        </div>
                        <div class="text-sm text-gray-500">
                            Stok: <span class="font-medium"><?php echo e($product->stok_produk); ?></span>
                        </div>
                    </div>

                    <div class="flex space-x-3">
                        <?php if(auth()->guard()->check()): ?>
                            <?php
                                $isWishlisted = \App\Models\Wishlist::where('id_user', \Illuminate\Support\Facades\Auth::user()->id_user)
                                    ->where('id_produk', $product->id_produk)
                                    ->exists();
                            ?>
                            <?php if($isWishlisted): ?>
                                <form action="<?php echo e(route('wishlist.destroy', $product->id_produk)); ?>" method="POST" class="flex-1">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="w-full px-6 py-3 border border-red-600 text-red-600 font-bold rounded-lg hover:bg-red-50 transition flex items-center justify-center">
                                        <i class="fas fa-heart mr-2"></i> Wishlist
                                    </button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('wishlist.store', $product->id_produk)); ?>" method="POST" class="flex-1">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="w-full px-6 py-3 border border-orange-600 text-orange-600 font-bold rounded-lg hover:bg-orange-50 transition flex items-center justify-center">
                                        <i class="far fa-heart mr-2"></i> Wishlist
                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="flex-1 px-6 py-3 border border-orange-600 text-orange-600 font-bold rounded-lg hover:bg-orange-50 transition flex items-center justify-center">
                                <i class="far fa-heart mr-2"></i> Wishlist
                            </a>
                        <?php endif; ?>

                        <form action="<?php echo e(route('cart.add', $product->id_produk)); ?>" method="POST" class="flex-1">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="quantity" id="quantityHidden" value="1">
                            <button type="submit" class="w-full px-6 py-3 bg-orange-600 text-white font-bold rounded-lg hover:bg-orange-700 transition flex items-center justify-center">
                                <i class="fas fa-plus mr-2"></i> Keranjang
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Related Products -->
    <?php if(isset($relatedProducts) && $relatedProducts->count() > 0): ?>
        <div class="mt-8">
            <h3 class="text-xl font-bold text-gray-800 mb-4">Produk Terkait</h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="bg-white rounded-lg shadow-sm border border-gray-100 p-4 hover:shadow-md transition">
                        <div class="h-32 bg-gray-100 rounded-md mb-3 flex items-center justify-center overflow-hidden">
                            <?php
                                $relatedImagePath = null;
                                if ($related->gambar_produk) {
                                    $rPath1 = 'storage/images/produk/' . $related->gambar_produk;
                                    $rPath2 = 'storage/images/produk/' . str_replace(' ', '', $related->gambar_produk);
                                    $rPath3 = 'storage/images/produk/' . strtolower(str_replace(' ', '', $related->gambar_produk));
                                    
                                    if (file_exists(public_path($rPath1))) $relatedImagePath = $rPath1;
                                    elseif (file_exists(public_path($rPath2))) $relatedImagePath = $rPath2;
                                    elseif (file_exists(public_path($rPath3))) $relatedImagePath = $rPath3;
                                }
                            ?>

                            <?php if($relatedImagePath): ?>
                                <img src="<?php echo e(asset($relatedImagePath)); ?>" 
                                     alt="<?php echo e($related->nama_produk); ?>" 
                                     class="w-full h-full object-cover">
                            <?php else: ?>
                                <i class="fas fa-box text-2xl text-gray-300"></i>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(route('products.show', $related->id_produk)); ?>" class="block text-sm font-medium text-gray-800 mb-1 hover:text-orange-600 line-clamp-2">
                            <?php echo e($related->nama_produk); ?>

                        </a>
                        <div class="text-orange-600 font-bold text-sm">
                            Rp <?php echo e(number_format($related->harga_produk, 0, ',', '.')); ?>

                        </div>
                     </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
    function incrementQty() {
        const input = document.getElementById('quantity');
        const hidden = document.getElementById('quantityHidden');
        const max = parseInt(input.getAttribute('max'));
        let val = parseInt(input.value);
        if (val < max) {
            input.value = val + 1;
            if (hidden) hidden.value = input.value;
        }
    }

    function decrementQty() {
        const input = document.getElementById('quantity');
        const hidden = document.getElementById('quantityHidden');
        let val = parseInt(input.value);
        if (val > 1) {
            input.value = val - 1;
            if (hidden) hidden.value = input.value;
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        const specBtn = document.getElementById('tabSpecBtn');
        const reviewBtn = document.getElementById('tabReviewBtn');
        const specTab = document.getElementById('tabSpec');
        const reviewTab = document.getElementById('tabReview');

        if (!specBtn || !reviewBtn || !specTab || !reviewTab) return;

        function setActive(active) {
            if (active === 'spec') {
                specTab.classList.remove('hidden');
                reviewTab.classList.add('hidden');
                specBtn.classList.add('text-orange-600', 'border-b-2', 'border-orange-600', 'bg-orange-50');
                specBtn.classList.remove('text-gray-600');
                reviewBtn.classList.remove('text-orange-600', 'border-b-2', 'border-orange-600', 'bg-orange-50');
                reviewBtn.classList.add('text-gray-600');
            } else {
                reviewTab.classList.remove('hidden');
                specTab.classList.add('hidden');
                reviewBtn.classList.add('text-orange-600', 'border-b-2', 'border-orange-600', 'bg-orange-50');
                reviewBtn.classList.remove('text-gray-600');
                specBtn.classList.remove('text-orange-600', 'border-b-2', 'border-orange-600', 'bg-orange-50');
                specBtn.classList.add('text-gray-600');
            }
        }

        specBtn.addEventListener('click', function () { setActive('spec'); });
        reviewBtn.addEventListener('click', function () { setActive('review'); });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aro\aro_ecommerce\resources\views/products/show.blade.php ENDPATH**/ ?>