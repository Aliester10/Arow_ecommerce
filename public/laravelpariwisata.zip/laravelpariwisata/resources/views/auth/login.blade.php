<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Login - {{ $settingwebsite->namaweb }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="{{ asset('storage/website/' . $settingwebsite->logo) }}" type="image/x-icon" />

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="min-vh-100">

    <div class="container-fluid min-vh-100">
        <div class="row min-vh-100">

            <!-- LEFT : LOGO / BRANDING -->
            <div class="col-md-6 d-none d-md-flex align-items-center justify-content-center text-white"
                style="background: linear-gradient(135deg, #1e3c72, #2a9d8f);">
                <div class="text-center px-4">
                    <img src="{{ asset('storage/website/' . $settingwebsite->logo) }}"
                        class="rounded-circle shadow mb-4" style="width:120px; height:120px; object-fit:cover;">
                    <h2 class="fw-bold">{{ $settingwebsite->namaweb }}</h2>
                    <p class="opacity-75">
                        Selamat datang! Silakan masuk untuk melanjutkan ke panel admin.
                    </p>
                </div>
            </div>

            <!-- RIGHT : LOGIN FORM -->
            <div class="col-md-6 d-flex align-items-center justify-content-center bg-light">
                <div class="card border-0 shadow-lg rounded-4 p-4" style="max-width: 400px; width:100%;">

                    <h4 class="text-center fw-bold text-primary mb-1">Login</h4>
                    <p class="text-center text-muted small mb-4">
                        Silakan masuk ke akun Anda
                    </p>

                    <form action="{{ url('loginproses') }}" method="POST">
                        @csrf

                        <div class="mb-3">
                            <label class="form-label small">Email</label>
                            <input type="email" name="email" class="form-control form-control-lg"
                                placeholder="Email">
                        </div>

                        <div class="mb-4">
                            <label class="form-label small">Password</label>
                            <input type="password" name="password" class="form-control form-control-lg"
                                placeholder="••••••">
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg w-100 fw-semibold">
                            Login
                        </button>
                    </form>

                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    @if (session('success'))
        <script>
            Swal.fire({
                icon: "success",
                title: "{{ session('success') }}",
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000
            });
        </script>
    @endif

    @if (session('error'))
        <script>
            Swal.fire({
                icon: "error",
                title: "{{ session('error') }}",
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000
            });
        </script>
    @endif

</body>

</html>
