@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex justify-content-between align-items-center">
                <h3 class="fw-bold">Edit Event</h3>
                <a href="{{ url('panel/event') }}" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            {{-- FORM --}}
            <div class="card mt-4">
                <div class="card-body">

                    <form action="{{ url('panel/eventupdate/' . $event->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Judul Event</label>
                                <input type="text" name="judul" value="{{ $event->judul }}" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Tanggal Mulai</label>
                                <input type="date" name="tanggalmulai" value="{{ $event->tanggalmulai }}"
                                    class="form-control" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Tanggal Selesai</label>
                                <input type="date" name="tanggalselesai" value="{{ $event->tanggalselesai }}"
                                    class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Lokasi</label>
                                <input type="text" name="lokasi" value="{{ $event->lokasi }}" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" id="deskripsi" rows="4">{{ $event->deskripsi }}</textarea>
                                <script>
                                    CKEDITOR.replace('deskripsi');
                                </script>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Poster</label>
                                <input type="file" name="poster" class="form-control" accept="image/*">
                                <small class="text-muted">
                                    Kosongkan jika tidak ingin mengganti poster
                                </small>

                                @if ($event->poster)
                                    <div class="mt-2">
                                        <img src="{{ asset('storage/poster/' . $event->poster) }}" class="img-thumbnail"
                                            width="180">
                                    </div>
                                @endif
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Status</label>
                                <select name="status" class="form-control" required>
                                    <option value="Aktif" {{ $event->status == 'Aktif' ? 'selected' : '' }}>
                                        Aktif
                                    </option>
                                    <option value="Non Aktif" {{ $event->status == 'Non Aktif' ? 'selected' : '' }}>
                                        Non Aktif
                                    </option>
                                </select>
                            </div>

                        </div>

                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
@endsection
