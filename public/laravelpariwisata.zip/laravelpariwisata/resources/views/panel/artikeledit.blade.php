@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex justify-content-between align-items-center">
                <h3 class="fw-bold">Edit Artikel</h3>
                <a href="{{ url('panel/artikel') }}" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            {{-- FORM --}}
            <div class="card mt-4">
                <div class="card-body">

                    <form action="{{ url('panel/artikelupdate/' . $artikel->id) }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Judul Artikel</label>
                                <input type="text" name="judul" class="form-control" value="{{ $artikel->judul }}"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Kategori</label>
                                <select name="kategoriartikel_id" class="form-control" required>
                                    <option value="">-- Pilih Kategori --</option>
                                    @foreach ($kategoriartikel as $kategori)
                                        <option value="{{ $kategori->id }}"
                                            {{ $artikel->kategoriartikel_id == $kategori->id ? 'selected' : '' }}>
                                            {{ $kategori->nama }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" id="deskripsi" class="form-control" rows="5">
                                    {{ $artikel->deskripsi }}
                                </textarea>
                                <script>
                                    CKEDITOR.replace('deskripsi');
                                </script>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Thumbnail</label>
                                <input type="file" name="thumbnail" class="form-control" accept="image/*">
                                <small class="text-muted">Kosongkan jika tidak diganti</small>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Status</label>
                                <select name="status" class="form-control" required>
                                    <option value="Aktif" {{ $artikel->status == 'Aktif' ? 'selected' : '' }}>
                                        Aktif
                                    </option>
                                    <option value="Non Aktif" {{ $artikel->status == 'Non Aktif' ? 'selected' : '' }}>
                                        Non Aktif
                                    </option>
                                </select>
                            </div>

                            @if ($artikel->thumbnail)
                                <div class="col-md-12 mb-3">
                                    <label class="fw-bold d-block">Thumbnail Saat Ini</label>
                                    <img src="{{ asset('storage/artikel/' . $artikel->thumbnail) }}" class="img-thumbnail"
                                        width="150">
                                </div>
                            @endif

                        </div>

                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-warning">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
@endsection
