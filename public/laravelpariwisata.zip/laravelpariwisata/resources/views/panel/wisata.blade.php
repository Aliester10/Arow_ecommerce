@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div class="flex-grow-1">
                    <h3 class="fw-bold mb-2 mb-md-0 text-center text-md-start">
                        Manajemen Wisata
                    </h3>
                </div>

                <div class="d-flex justify-content-end gap-2">
                    <a href="{{ url('panel/wisatatambah') }}" class="btn btn-primary">
                        <i class="fa fa-plus me-1"></i> Tambah Wisata
                    </a>
                </div>
            </div>

            {{-- TABLE --}}
            <div class="card mt-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle w-100" id="datatable">
                            <thead class="table-primary text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Judul</th>
                                    <th>Kategori</th>
                                    <th>Jam Buka</th>
                                    <th>Jam Tutup</th>
                                    <th>Tiket</th>
                                    <th>Koordinat</th>
                                    <th>Foto</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($wisata as $key => $value)
                                    <tr>
                                        <td class="text-center">{{ $key + 1 }}</td>
                                        <td>{{ $value->judul }}</td>
                                        <td>{{ $value->kategori->nama ?? '-' }}</td>
                                        <td>{{ $value->jambuka }}</td>
                                        <td>{{ $value->jamtutup }}</td>
                                        <td>Rp {{ number_format($value->hargatiket) }}</td>
                                        <td class="text-center">
                                            {{ $value->lat }}, {{ $value->lng }}
                                        </td>
                                        <td class="text-center">
                                            <img src="{{ asset('storage/thumbnail/' . $value->thumbnail) }}" alt="Foto"
                                                width="100">
                                        </td>
                                        <td class="text-center">
                                            @if ($value->status == 'Aktif')
                                                <span class="badge bg-success">Aktif</span>
                                            @else
                                                <span class="badge bg-secondary">Non Aktif</span>
                                            @endif
                                        </td>
                                        <td class="text-center">
                                            <a href="{{ url('panel/wisataedit/' . $value->id) }}"
                                                class="btn btn-sm btn-warning">
                                                <i class="fa fa-edit"></i>
                                            </a>

                                            <form action="{{ url('panel/wisatahapus/' . $value->id) }}" method="POST"
                                                class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Hapus data ini?')">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection
