@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div class="flex-grow-1">
                    <h3 class="fw-bold mb-2 mb-md-0 text-center text-md-start">
                        Edit Kategori Galeri
                    </h3>
                </div>

                <div class="d-flex flex-wrap justify-content-center justify-content-md-end gap-2">
                    <a href="{{ url('panel/kategorigaleri') }}" class="btn btn-secondary">
                        <i class="fa fa-arrow-left me-1"></i> Kembali
                    </a>
                </div>
            </div>

            {{-- FORM --}}
            <div class="card mt-4">
                <div class="card-body">

                    <form action="{{ url('panel/kategorigaleriupdate/' . $kategori->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Kategori</label>
                                <input type="text" name="nama" class="form-control"
                                    value="{{ old('nama', $kategori->nama) }}" required>
                            </div>

                        </div>

                        <div class="d-flex justify-content-end gap-2 mt-3">
                            <button type="reset" class="btn btn-warning">
                                <i class="fa fa-undo me-1"></i> Reset
                            </button>

                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
@endsection
