@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header mb-4">
                <h3 class="fw-bold">Edit Hero</h3>
            </div>

            {{-- CARD --}}
            <div class="card">
                <div class="card-body">

                    <form action="{{ url('panel/heroupdate/' . $hero->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Judul</label>
                                <input type="text" name="judul" class="form-control" value="{{ $hero->judul }}"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" rows="5" required>{{ $hero->deskripsi }}</textarea>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Foto</label>
                                <input type="file" name="foto" class="form-control" accept="image/*">
                                <small class="text-muted">
                                    Kosongkan jika tidak ingin mengganti foto
                                </small>
                            </div>

                            @if ($hero->foto)
                                <div class="col-md-12 mb-3">
                                    <label class="fw-bold d-block">Foto Saat Ini</label>
                                    <img src="{{ asset('storage/hero/' . $hero->foto) }}" width="200"
                                        class="img-thumbnail">
                                </div>
                            @endif

                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                Update
                            </button>
                            <a href="{{ url('panel/hero') }}" class="btn btn-secondary">
                                Kembali
                            </a>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
@endsection
