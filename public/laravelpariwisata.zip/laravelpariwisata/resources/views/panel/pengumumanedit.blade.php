@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex justify-content-between align-items-center">
                <h3 class="fw-bold">Edit Pengumuman</h3>
                <a href="{{ url('panel/pengumuman') }}" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            {{-- FORM --}}
            <div class="card mt-4">
                <div class="card-body">

                    <form action="{{ url('panel/pengumumanupdate/' . $pengumuman->id) }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="row">

                            {{-- JUDUL --}}
                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Judul Pengumuman</label>
                                <input type="text" name="judul" value="{{ $pengumuman->judul }}" class="form-control"
                                    required>
                            </div>

                            {{-- DESKRIPSI --}}
                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" id="deskripsi" class="form-control" rows="5">{{ $pengumuman->deskripsi }}</textarea>
                                <script>
                                    CKEDITOR.replace('deskripsi');
                                </script>
                            </div>

                            {{-- FILE --}}
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">File</label>
                                <input type="file" name="file" class="form-control">

                                @if ($pengumuman->file)
                                    <div class="mt-2">
                                        <small class="text-muted d-block">File Saat Ini:</small>

                                        @if (Str::endsWith($pengumuman->file, ['.jpg', '.jpeg', '.png', '.webp']))
                                            <img src="{{ asset('storage/pengumuman/' . $pengumuman->file) }}"
                                                class="img-thumbnail mt-1" width="150">
                                        @else
                                            <a href="{{ asset('storage/pengumuman/' . $pengumuman->file) }}"
                                                target="_blank">
                                                Lihat File
                                            </a>
                                        @endif
                                    </div>
                                @endif
                            </div>

                            {{-- THUMBNAIL --}}
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Thumbnail</label>
                                <input type="file" name="thumbnail" class="form-control" accept="image/*">

                                @if ($pengumuman->thumbnail)
                                    <div class="mt-2">
                                        <small class="text-muted d-block">Thumbnail Saat Ini:</small>
                                        <img src="{{ asset('storage/pengumuman/' . $pengumuman->thumbnail) }}"
                                            class="img-thumbnail" width="150">
                                    </div>
                                @endif
                            </div>

                        </div>

                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
@endsection
