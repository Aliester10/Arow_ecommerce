@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex justify-content-between align-items-center">
                <h3 class="fw-bold">Edit Struktur Organisasi</h3>
                <a href="{{ url('panel/strukturorganisasi') }}" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            {{-- FORM --}}
            <div class="card mt-4">
                <div class="card-body">

                    <form action="{{ url('panel/strukturorganisasiupdate/' . $strukturorganisasi->id) }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="row">

                            {{-- NAMA --}}
                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Nama</label>
                                <input type="text" name="nama" class="form-control"
                                    value="{{ $strukturorganisasi->nama }}" required>
                            </div>

                            {{-- JABATAN --}}
                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Jabatan</label>
                                <input type="text" name="jabatan" class="form-control"
                                    value="{{ $strukturorganisasi->jabatan }}" required>
                            </div>

                            {{-- FOTO --}}
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Foto</label>
                                <input type="file" name="foto" class="form-control" accept="image/*">
                                <small class="text-muted">
                                    Kosongkan jika tidak ingin mengganti foto
                                </small>
                            </div>

                            {{-- PREVIEW FOTO --}}
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold d-block">Foto Saat Ini</label>
                                @if ($strukturorganisasi->foto)
                                    <img src="{{ asset('storage/strukturorganisasi/' . $strukturorganisasi->foto) }}"
                                        class="img-thumbnail" width="180">
                                @else
                                    <span class="text-muted">Tidak ada foto</span>
                                @endif
                            </div>

                        </div>

                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
@endsection
