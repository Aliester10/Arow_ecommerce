@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Dashboard</h3>
                    <p class="text-muted mb-0">Selamat datang, {{ $user->name }}</p>
                </div>
            </div>

            {{-- SUMMARY CARDS --}}
            <div class="row g-4 mb-4">
                <div class="col-md-3 col-sm-6">
                    <div class="card shadow-sm text-center p-3">
                        <i class="fas fa-map-marker-alt fa-2x mb-2 text-primary"></i>
                        <h6 class="text-muted">Total Wisata</h6>
                        <h3 class="fw-bold">{{ $totalWisata }}</h3>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card shadow-sm text-center p-3">
                        <i class="fas fa-calendar-alt fa-2x mb-2 text-success"></i>
                        <h6 class="text-muted">Total Event</h6>
                        <h3 class="fw-bold">{{ $totalEvent }}</h3>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card shadow-sm text-center p-3">
                        <i class="fas fa-newspaper fa-2x mb-2 text-warning"></i>
                        <h6 class="text-muted">Total Artikel</h6>
                        <h3 class="fw-bold">{{ $totalArtikel }}</h3>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card shadow-sm text-center p-3">
                        <i class="fas fa-bullhorn fa-2x mb-2 text-danger"></i>
                        <h6 class="text-muted">Total Pengumuman</h6>
                        <h3 class="fw-bold">{{ $totalPengumuman }}</h3>
                    </div>
                </div>
            </div>

            {{-- HIGHLIGHTS --}}
            <div class="row g-4">

                {{-- Wisata Unggulan --}}
                <div class="col-md-4">
                    <h5 class="fw-bold mb-3">Wisata Unggulan</h5>
                    <div class="row g-2">
                        @forelse ($wisataUnggulan as $wisata)
                            <div class="col-12 d-flex align-items-center shadow-sm rounded p-2 mb-2">
                                <img src="{{ asset('storage/thumbnail/' . $wisata->thumbnail) }}" width="60"
                                    class="rounded me-3">
                                <div>
                                    <h6 class="mb-0">{{ $wisata->judul }}</h6>
                                    <small class="text-muted">{{ $wisata->desa }}, {{ $wisata->kecamatan }}</small>
                                </div>
                            </div>
                        @empty
                            <p class="text-muted">Belum ada wisata unggulan</p>
                        @endforelse
                    </div>
                </div>

                {{-- Event Terdekat --}}
                <div class="col-md-4">
                    <h5 class="fw-bold mb-3">Event Terdekat</h5>
                    <div class="row g-2">
                        @forelse ($eventTerdekat as $event)
                            <div class="col-12 d-flex align-items-center shadow-sm rounded p-2 mb-2">
                                <img src="{{ asset('storage/poster/' . $event->poster) }}" width="60"
                                    class="rounded me-3">
                                <div>
                                    <h6 class="mb-0">{{ $event->judul }}</h6>
                                    <small class="text-muted">
                                        {{ \Carbon\Carbon::parse($event->tanggalmulai)->format('d M Y') }}
                                        - {{ \Carbon\Carbon::parse($event->tanggalselesai)->format('d M Y') }}
                                    </small>
                                </div>
                            </div>
                        @empty
                            <p class="text-muted">Tidak ada event terdekat</p>
                        @endforelse
                    </div>
                </div>

                {{-- Artikel Terbaru --}}
                <div class="col-md-4">
                    <h5 class="fw-bold mb-3">Artikel Terbaru</h5>
                    <div class="row g-2">
                        @forelse ($artikelTerbaru as $artikel)
                            <div class="col-12 d-flex align-items-center shadow-sm rounded p-2 mb-2">
                                @if ($artikel->thumbnail)
                                    <img src="{{ asset('storage/artikel/' . $artikel->thumbnail) }}" width="60"
                                        class="rounded me-3">
                                @endif
                                <div>
                                    <h6 class="mb-0">{{ $artikel->judul }}</h6>
                                    <small class="text-muted">{{ $artikel->kategoriartikel->nama ?? '-' }}</small>
                                </div>
                            </div>
                        @empty
                            <p class="text-muted">Belum ada artikel terbaru</p>
                        @endforelse
                    </div>
                </div>

            </div>

        </div>
    </div>
@endsection
