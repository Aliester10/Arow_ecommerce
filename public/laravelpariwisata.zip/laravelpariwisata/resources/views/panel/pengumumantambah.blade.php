@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex justify-content-between align-items-center">
                <h3 class="fw-bold">Tambah Pengumuman</h3>
                <a href="{{ url('panel/pengumuman') }}" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            {{-- FORM --}}
            <div class="card mt-4">
                <div class="card-body">

                    <form action="{{ url('panel/pengumumansimpan') }}" method="POST" enctype="multipart/form-data">
                        @csrf

                        <div class="row">

                            {{-- JUDUL --}}
                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Judul Pengumuman</label>
                                <input type="text" name="judul" class="form-control" required>
                            </div>

                            {{-- DESKRIPSI --}}
                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" id="deskripsi" class="form-control" rows="5"></textarea>
                                <script>
                                    CKEDITOR.replace('deskripsi');
                                </script>
                            </div>

                            {{-- FILE UTAMA --}}
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">File</label>
                                <input type="file" name="file" class="form-control" required>
                            </div>

                            {{-- THUMBNAIL --}}
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Thumbnail</label>
                                <input type="file" name="thumbnail" class="form-control" accept="image/*" required>
                            </div>

                        </div>

                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save me-1"></i> Simpan
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
@endsection
