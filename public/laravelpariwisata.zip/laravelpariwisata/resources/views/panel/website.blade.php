@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold">Edit Website</h3>
                <a href="{{ url('panel/website') }}" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            {{-- FORM CARD --}}
            <div class="card">
                <div class="card-body">

                    <form action="{{ url('panel/websiteupdate') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Nama Website</label>
                                <input type="text" name="namaweb" class="form-control" value="{{ $website->namaweb }}"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Tentang</label>
                                <textarea name="tentang" class="form-control" rows="4" id="tentang" required>{{ $website->tentang }}</textarea>
                                <script>
                                    CKEDITOR.replace('tentang');
                                </script>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Visi</label>
                                <textarea name="visi" class="form-control" rows="3" required>{{ $website->visi }}</textarea>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Misi</label>
                                <textarea name="misi" class="form-control" rows="3" id="misi" required>{{ $website->misi }}</textarea>
                                <script>
                                    CKEDITOR.replace('misi');
                                </script>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Logo</label>
                                <input type="file" name="logo" class="form-control" accept="image/*">
                                <small class="text-muted">Kosongkan jika tidak ingin mengganti logo</small>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Email</label>
                                <input type="email" name="email" class="form-control" value="{{ $website->email }}"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">No HP</label>
                                <input type="text" name="nohp" class="form-control" value="{{ $website->nohp }}"
                                    required>
                            </div>

                            @if ($website->logo)
                                <div class="col-md-12 mb-3">
                                    <label class="fw-bold d-block">Logo Saat Ini</label>
                                    <img src="{{ asset('storage/website/' . $website->logo) }}" width="120"
                                        class="img-thumbnail">
                                </div>
                            @endif

                        </div>

                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-warning">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
@endsection
