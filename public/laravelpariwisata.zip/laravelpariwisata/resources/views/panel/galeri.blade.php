@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div class="flex-grow-1">
                    <h3 class="fw-bold mb-2 mb-md-0 text-center text-md-start">
                        Manajemen Galeri
                    </h3>
                </div>

                <div class="d-flex flex-wrap justify-content-center justify-content-md-end gap-2">
                    <a href="{{ url('panel/galeritambah') }}" class="btn btn-primary">
                        <i class="fa fa-plus me-1"></i> Tambah Galeri
                    </a>
                </div>
            </div>

            {{-- TABLE --}}
            <div class="card mt-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle w-100" id="datatable">
                            <thead class="table-primary text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Judul</th>
                                    <th>Kategori</th>
                                    <th>Tipe</th>
                                    <th>File</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>

                            <tbody>
                                @foreach ($galeri as $key => $value)
                                    <tr>
                                        <td class="text-center">{{ $key + 1 }}</td>
                                        <td>{{ $value->judul }}</td>
                                        <td>{{ $value->kategorigaleri->nama ?? '-' }}</td>
                                        <td>{{ $value->tipe }}</td>
                                        <td class="text-center">
                                            @if ($value->file)
                                                <a href="{{ asset('storage/galeri/' . $value->file) }}" target="_blank">
                                                    Lihat File
                                                </a>
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td class="text-center">

                                            <a href="{{ url('panel/galeriedit/' . $value->id) }}"
                                                class="btn btn-sm btn-warning">
                                                <i class="fa fa-edit"></i>
                                            </a>

                                            <form action="{{ url('panel/galerihapus/' . $value->id) }}" method="POST"
                                                class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Hapus galeri ini?')">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>

                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection
