@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex justify-content-between align-items-center">
                <h3 class="fw-bold">Edit Wisata</h3>
                <a href="{{ url('panel/wisata') }}" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            <div class="card mt-4">
                <div class="card-body">

                    <form action="{{ url('panel/wisataupdate/' . $wisata->id) }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="row">

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Judul Wisata</label>
                                <input type="text" name="judul" value="{{ $wisata->judul }}" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Kategori</label>
                                <select name="kategori_id" class="form-control" required>
                                    @foreach ($kategori as $k)
                                        <option value="{{ $k->id }}"
                                            {{ $wisata->kategori_id == $k->id ? 'selected' : '' }}>
                                            {{ $k->nama }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Jam Buka</label>
                                <input type="time" name="jambuka" value="{{ $wisata->jambuka }}" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Jam Tutup</label>
                                <input type="time" name="jamtutup" value="{{ $wisata->jamtutup }}" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Alamat</label>
                                <input type="text" name="alamat" value="{{ $wisata->alamat }}" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Desa</label>
                                <input type="text" name="desa" value="{{ $wisata->desa }}" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Kecamatan</label>
                                <input type="text" name="kecamatan" value="{{ $wisata->kecamatan }}"
                                    class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" id="deskripsi" rows="3">{{ $wisata->deskripsi }}</textarea>
                                <script>
                                    CKEDITOR.replace('deskripsi');
                                </script>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Harga Tiket</label>
                                <input type="number" name="hargatiket" value="{{ $wisata->hargatiket }}"
                                    class="form-control" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Koordinat</label>
                                <div class="d-flex gap-2">
                                    <input type="text" name="lat" value="{{ $wisata->lat }}" class="form-control"
                                        readonly>
                                    <input type="text" name="lng" value="{{ $wisata->lng }}" class="form-control"
                                        readonly>
                                </div>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Lokasi Wisata</label>
                                <div id="map" style="height: 400px; border-radius: 12px;"></div>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Thumbnail</label>
                                <input type="file" name="thumbnail" class="form-control">
                                @if ($wisata->thumbnail)
                                    <img src="{{ asset('storage/thumbnail/' . $wisata->thumbnail) }}"
                                        class="img-thumbnail mt-2" width="150">
                                @endif
                            </div>

                            <div class="col-md-6 mb-3">
                                <label>Status</label>
                                <select name="status" class="form-control" required>
                                    <option value="Aktif" {{ $wisata->status == 'Aktif' ? 'selected' : '' }}>Aktif
                                    </option>
                                    <option value="Non Aktif" {{ $wisata->status == 'Non Aktif' ? 'selected' : '' }}>
                                        Non
                                        Aktif</option>
                                </select>
                            </div>

                        </div>

                        <div class="text-end">
                            <button class="btn btn-primary">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                        </div>

                    </form>

                    <hr>

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold mb-0">Foto Wisata</h5>
                        <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalTambahFoto">
                            <i class="fa fa-plus me-1"></i> Tambah Foto
                        </button>
                    </div>

                    <table class="table table-bordered align-middle">
                        <thead class="table-light text-center">
                            <tr>
                                <th>Foto</th>
                                <th width="100">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($wisata->wisatafoto as $foto)
                                <tr>
                                    <td>
                                        <img src="{{ asset('storage/wisatafoto/' . $foto->foto) }}" width="120"
                                            class="img-thumbnail">
                                    </td>
                                    <td class="text-center">
                                        <form action="{{ url('panel/wisatafotohapus/' . $foto->id) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn btn-sm btn-danger"
                                                onclick="return confirm('Hapus foto ini?')">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div class="modal fade" id="modalTambahFoto" tabindex="-1">
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            <div class="modal-content">

                                <div class="modal-header bg-success text-white">
                                    <h5 class="modal-title">Tambah Foto Wisata</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>

                                <form action="{{ url('panel/wisatafotosimpan/' . $wisata->id) }}" method="POST"
                                    enctype="multipart/form-data">
                                    @csrf

                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label class="fw-bold">Pilih Foto</label>
                                            <input type="file" name="wisatafoto[]" class="form-control"
                                                accept="image/*" multiple required>
                                            <small class="text-muted">
                                                Bisa pilih lebih dari satu foto
                                            </small>
                                        </div>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                            Batal
                                        </button>
                                        <button type="submit" class="btn btn-success">
                                            <i class="fa fa-upload me-1"></i> Upload
                                        </button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>


                </div>
            </div>

        </div>
    </div>
@endsection
@section('script')
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css">
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script>
        let map, marker;

        document.addEventListener('DOMContentLoaded', function() {

            const lat = {{ $wisata->lat }};
            const lng = {{ $wisata->lng }};

            map = L.map('map').setView([lat, lng], 14);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap'
            }).addTo(map);

            marker = L.marker([lat, lng]).addTo(map);

            map.on('click', function(e) {
                const newLat = e.latlng.lat.toFixed(6);
                const newLng = e.latlng.lng.toFixed(6);

                document.querySelector('input[name="lat"]').value = newLat;
                document.querySelector('input[name="lng"]').value = newLng;

                marker.setLatLng(e.latlng);
            });
        });
    </script>
@endsection
