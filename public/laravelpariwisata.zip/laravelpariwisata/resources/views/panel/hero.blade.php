@extends('layouts.panel')

@section('content')
    <div class="container">
        <div class="page-inner">

            {{-- HEADER --}}
            <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div class="flex-grow-1">
                    <h3 class="fw-bold mb-2 mb-md-0 text-center text-md-start">
                        Manajemen Hero
                    </h3>
                </div>

                <div class="d-flex flex-wrap justify-content-center justify-content-md-end gap-2">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambahHero">
                        <i class="fa fa-plus me-1"></i> Tambah Hero
                    </button>
                </div>
            </div>

            {{-- TABLE --}}
            <div class="card mt-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle w-100" id="datatable">
                            <thead class="table-primary text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Judul</th>
                                    <th>Deskripsi</th>
                                    <th>Foto</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>

                            <tbody>
                                @foreach ($hero as $key => $value)
                                    <tr>
                                        <td class="text-center">{{ $key + 1 }}</td>
                                        <td>{{ $value->judul }}</td>
                                        <td>{{ Str::limit($value->deskripsi, 80) }}</td>
                                        <td class="text-center">
                                            @if ($value->foto)
                                                <img src="{{ asset('storage/hero/' . $value->foto) }}" width="100"
                                                    class="img-thumbnail">
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td class="text-center">

                                            <a href="{{ url('panel/heroedit/' . $value->id) }}"
                                                class="btn btn-sm btn-warning">
                                                <i class="fa fa-edit"></i>
                                            </a>

                                            <form action="{{ url('panel/herohapus/' . $value->id) }}" method="POST"
                                                class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Hapus data ini?')">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>

                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

    {{-- MODAL TAMBAH HERO --}}
    <div class="modal fade" id="modalTambahHero" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Tambah Hero</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="{{ url('panel/herosimpan') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Judul</label>
                                <input type="text" name="judul" class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" rows="4" required></textarea>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Foto</label>
                                <input type="file" name="foto" class="form-control" accept="image/*" required>
                            </div>

                        </div>

                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">
                            Simpan
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>
@endsection
