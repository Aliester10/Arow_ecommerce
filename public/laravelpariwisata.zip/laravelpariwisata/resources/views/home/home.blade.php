@extends('layouts.home')
@section('content')
    <!-- Carousel -->
    <style>
        #header-carousel .carousel-item {
            height: 80vh;
            min-height: 500px;
            position: relative;
        }

        #header-carousel .carousel-item img {
            height: 100%;
            width: 100%;
            object-fit: cover;
        }

        .carousel-caption h5,
        .carousel-caption h1 {
            animation-duration: 1s;
        }
    </style>

    <div class="container-fluid p-0 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">

            <div class="carousel-indicators">
                @foreach ($hero as $index => $item)
                    <button type="button" data-bs-target="#header-carousel" data-bs-slide-to="{{ $index }}"
                        class="{{ $index == 0 ? 'active' : '' }}" aria-current="{{ $index == 0 ? 'true' : 'false' }}"
                        aria-label="Slide {{ $index + 1 }}"></button>
                @endforeach
            </div>

            <div class="carousel-inner">
                @foreach ($hero as $index => $item)
                    <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                        <img class="w-100" src="{{ asset('storage/hero/' . $item->foto) }}" alt="{{ $item->judul }}" />

                        <div class="carousel-caption">
                            <div class="container">
                                <div class="row justify-content-center">
                                    <div class="col-12 col-lg-10">
                                        <h5 class="text-light text-uppercase mb-3 animated slideInDown">
                                            {{ $item->judul }}
                                        </h5>
                                        <h5 class="display-5 text-light mb-3 animated slideInDown">
                                            {!! Str::limit($item->deskripsi, 100) !!}
                                        </h5>
                                        @if (url()->current() != url('/artikel'))
                                            <a href="{{ url('artikel') }}" class="btn btn-primary py-3 px-5">
                                                Baca Artikel
                                            </a>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5 align-items-center">

                <div class="col-lg-6">
                    <div class="position-relative overflow-hidden ps-5 pt-5 h-100" style="min-height: 400px;">
                        <img class="position-absolute w-100 h-100"
                            src="{{ asset('storage/website/' . $settingwebsite->logo) }}"
                            style="object-fit: cover; border-radius: 8px;">

                        <div class="position-absolute top-0 start-0 bg-white pe-3 pb-3"
                            style="width: 220px; height: 220px; border-radius:8px;">
                            <div class="d-flex flex-column justify-content-center text-center bg-primary h-100 p-3 rounded">
                                <h5 class="text-white mb-0">{{ $settingwebsite->namaweb }}</h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div>
                        <div class="border-start border-5 border-primary ps-4 mb-4">
                            <h2 class="fw-bold mb-0">Tentang {{ $settingwebsite->namaweb }}</h2>
                        </div>

                        {!! $settingwebsite->tentang !!}


                        <div class="row g-4">
                            <div class="col-sm-6 d-flex align-items-center">
                                <i class="fa fa-map-marker-alt fa-2x text-primary me-3"></i>
                                <h6 class="mb-0">Destinasi Wisata</h6>
                            </div>

                            <div class="col-sm-6 d-flex align-items-center">
                                <i class="fa fa-landmark fa-2x text-primary me-3"></i>
                                <h6 class="mb-0">Budaya & Event</h6>
                            </div>

                            <div class="col-sm-6 d-flex align-items-center">
                                <i class="fa fa-hand-holding-usd fa-2x text-primary me-3"></i>
                                <h6 class="mb-0">Dukung Pelaku Wisata</h6>
                            </div>

                            <div class="col-sm-6 d-flex align-items-center">
                                <i class="fa fa-info-circle fa-2x text-primary me-3"></i>
                                <h6 class="mb-0">Transparansi Informasi</h6>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="container-xxl py-5 bg-light">
        <div class="container">
            <div class="row justify-content-center text-center mb-5">
                <div class="col-lg-8">
                    <h6 class="text-primary text-uppercase mb-2">
                        Fitur {{ $settingwebsite->namaweb }}
                    </h6>
                    <h2 class="fw-bold mb-3">
                        Portal Informasi Pariwisata Cianjur
                    </h2>
                    <p class="text-muted">
                        {{ $settingwebsite->namaweb }} memudahkan masyarakat dan wisatawan untuk menemukan informasi
                        lengkap mengenai destinasi, budaya, event, dan dukungan bagi pelaku wisata.
                    </p>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-md-4 text-center">
                    <div class="p-4 h-100 shadow-sm rounded bg-white">
                        <i class="fa fa-map fa-3x text-primary mb-3"></i>
                        <h5 class="fw-bold">Media Informasi Resmi</h5>
                        <p class="text-muted mb-0">
                            Menyediakan informasi resmi dan terpercaya tentang pariwisata Cianjur.
                        </p>
                    </div>
                </div>

                <div class="col-md-4 text-center">
                    <div class="p-4 h-100 shadow-sm rounded bg-white">
                        <i class="fa fa-camera-retro fa-3x text-primary mb-3"></i>
                        <h5 class="fw-bold">Promosi Destinasi & Event</h5>
                        <p class="text-muted mb-0">
                            Mempromosikan destinasi wisata, budaya, dan event yang menarik di Cianjur.
                        </p>
                    </div>
                </div>

                <div class="col-md-4 text-center">
                    <div class="p-4 h-100 shadow-sm rounded bg-white">
                        <i class="fa fa-handshake fa-3x text-primary mb-3"></i>
                        <h5 class="fw-bold">Dukungan Pelaku Wisata</h5>
                        <p class="text-muted mb-0">
                            Memberikan informasi dan media promosi untuk mendukung pelaku wisata lokal.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
