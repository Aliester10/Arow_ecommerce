@extends('layouts.home')

@section('content')
    {{-- HEADER --}}
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-5 text-white animated slideInDown mb-3">
                {{ $artikel->judul }}
            </h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="{{ url('/') }}">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a class="text-white" href="{{ url('/artikel') }}">Artikel</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        Detail Artikel
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    {{-- CONTENT --}}
    <div class="container-xxl py-5">
        <div class="container">

            <div class="row g-5 justify-content-center">

                <div class="col-lg-9">

                    {{-- THUMBNAIL --}}
                    <div class="artikel-image mb-4 shadow-sm">
                        <img src="{{ asset('storage/artikel/' . $artikel->thumbnail) }}" alt="{{ $artikel->judul }}">
                    </div>

                    {{-- META --}}
                    <div class="d-flex flex-wrap align-items-center mb-3 artikel-meta">
                        <span class="badge bg-primary me-2">
                            {{ $artikel->kategoriartikel->nama ?? 'Artikel' }}
                        </span>

                        <small class="text-muted me-3">
                            <i class="fa fa-calendar me-1"></i>
                            {{ date('d M Y', strtotime($artikel->created_at)) }}
                        </small>

                        <small class="text-muted">
                            <i class="fa fa-user me-1"></i>
                            {{ $artikel->publishedby->name ?? 'Admin' }}
                        </small>
                    </div>

                    {{-- JUDUL --}}
                    <h1 class="fw-bold mb-4">
                        {{ $artikel->judul }}
                    </h1>

                    {{-- DESKRIPSI --}}
                    <div class="artikel-content mb-5">
                        {!! $artikel->deskripsi !!}
                    </div>

                    {{-- FOOTER --}}
                    <div class="d-flex justify-content-between align-items-center">
                        <a href="{{ url('/artikel') }}" class="btn btn-outline-primary">
                            <i class="fa fa-arrow-left me-2"></i>
                            Kembali ke Artikel
                        </a>

                        {{-- <div class="share">
                            <span class="me-2 text-muted">Bagikan:</span>
                            <a href="#" class="btn btn-sm btn-outline-success me-1">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                            <a href="#" class="btn btn-sm btn-outline-primary me-1">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="btn btn-sm btn-outline-danger">
                                <i class="fab fa-instagram"></i>
                            </a>
                        </div> --}}
                    </div>

                </div>

            </div>

        </div>
    </div>

    {{-- STYLE --}}
    <style>
        .artikel-image {
            border-radius: 18px;
            overflow: hidden;
        }

        .artikel-image img {
            width: 100%;
            height: 420px;
            object-fit: cover;
            transition: transform .4s ease;
        }

        .artikel-image:hover img {
            transform: scale(1.05);
        }

        .artikel-meta {
            font-size: 0.9rem;
        }

        .artikel-content {
            line-height: 1.8;
            font-size: 1.05rem;
        }

        .artikel-content img {
            max-width: 100%;
            border-radius: 12px;
            margin: 15px 0;
        }

        .artikel-content p {
            margin-bottom: 1rem;
        }
    </style>
@endsection
