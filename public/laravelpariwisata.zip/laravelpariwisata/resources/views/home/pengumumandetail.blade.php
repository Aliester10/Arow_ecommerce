@extends('layouts.home')

@section('content')
    {{-- HEADER --}}
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn">
        <div class="container text-center py-5">
            <h1 class="display-5 text-white mb-3">
                {{ $pengumuman->judul }}
            </h1>
            <nav>
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="{{ url('/') }}">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a class="text-white" href="{{ url('/pengumuman') }}">Pengumuman</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        Detail
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    {{-- CONTENT --}}
    <div class="container-xxl py-5">
        <div class="container">

            <div class="row g-5">

                {{-- KONTEN --}}
                <div class="col-lg-8">

                    <div class="card border-0 shadow-sm p-4 rounded-4">

                        {{-- THUMBNAIL --}}
                        <img src="{{ asset('storage/pengumuman/' . $pengumuman->thumbnail) }}"
                            class="img-fluid rounded mb-4" alt="{{ $pengumuman->judul }}">

                        {{-- META --}}
                        <div class="mb-3 text-muted small">
                            <i class="fa fa-calendar me-1"></i>
                            {{ date('d M Y', strtotime($pengumuman->created_at)) }}
                        </div>

                        {{-- JUDUL --}}
                        <h2 class="fw-bold mb-4">
                            {{ $pengumuman->judul }}
                        </h2>

                        {{-- DESKRIPSI --}}
                        <div class="pengumuman-content">
                            {!! $pengumuman->deskripsi !!}
                        </div>

                        {{-- FILE --}}
                        <div class="mt-4">
                            <a href="{{ asset('storage/pengumuman/' . $pengumuman->file) }}" target="_blank"
                                class="btn btn-primary px-4">
                                <i class="fa fa-download me-2"></i>
                                Download Lampiran
                            </a>
                        </div>

                    </div>

                </div>

                {{-- SIDEBAR --}}
                <div class="col-lg-4">

                    <div class="card border-0 shadow-sm rounded-4 p-4">

                        <h5 class="fw-bold mb-3">
                            Informasi Pengumuman
                        </h5>

                        <ul class="list-unstyled mb-0 small">
                            <li class="mb-2">
                                <i class="fa fa-calendar text-primary me-2"></i>
                                {{ date('d M Y', strtotime($pengumuman->created_at)) }}
                            </li>
                            <li>
                                <i class="fa fa-file text-primary me-2"></i>
                                File Lampiran
                            </li>
                        </ul>

                    </div>
                    @if ($pengumuman->file)
                        <a href="{{ url('pengumuman') }}" class="btn btn-outline-primary w-100 mt-4">
                            <i class="fa fa-arrow-left me-2"></i>
                            Kembali ke Pengumuman
                        </a>
                    @endif

                </div>

            </div>

        </div>
    </div>

    {{-- STYLE --}}
    <style>
        .pengumuman-content p {
            line-height: 1.8;
            margin-bottom: 1rem;
        }

        .pengumuman-content img {
            max-width: 100%;
            border-radius: 12px;
            margin: 15px 0;
        }
    </style>
@endsection
