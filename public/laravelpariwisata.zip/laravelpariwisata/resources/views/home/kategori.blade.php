@extends('layouts.home')

@section('content')
    {{-- HEADER --}}
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-4">
                Wisata {{ $kategori->nama ?? '' }}
            </h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="{{ url('/') }}">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a class="text-white" href="{{ url('/wisata') }}">Wisata</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        {{ $kategori->nama ?? 'Kategori' }}
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    {{-- CONTENT --}}
    <div class="container-xxl py-5">
        <div class="container">

            {{-- JUDUL --}}
            <div class="text-center mb-5">
                <h6 class="text-primary text-uppercase">
                    Visit Cianjur
                </h6>
                <h1 class="display-6 fw-bold">
                    Destinasi Wisata {{ $kategori->nama ?? '' }}
                </h1>
                <p class="text-muted">
                    Jelajahi destinasi wisata terbaik di Kabupaten Cianjur
                </p>
            </div>

            <div class="row g-4">

                @foreach ($wisata as $item)
                    <div class="col-lg-4 col-md-6">
                        <div class="card wisata-card h-100 border-0 shadow-sm">

                            <div class="position-relative overflow-hidden">
                                <img src="{{ asset('storage/thumbnail/' . $item->thumbnail) }}" class="w-100"
                                    style="height: 230px; object-fit: cover;" alt="{{ $item->judul }}">

                                <span class="badge bg-primary position-absolute top-0 start-0 m-3">
                                    {{ $item->kategori->nama ?? 'Wisata' }}
                                </span>
                            </div>

                            <div class="card-body d-flex flex-column">
                                <h5 class="fw-bold mb-2">
                                    {{ $item->judul }}
                                </h5>

                                <p class="text-muted small mb-3">
                                    <i class="fa fa-map-marker-alt text-primary me-1"></i>
                                    {{ $item->desa }}, {{ $item->kecamatan }}
                                </p>

                                <p class="text-muted mb-4">
                                    {{ Str::limit(strip_tags($item->deskripsi), 100) }}
                                </p>

                                <a href="{{ url('wisatadetail/' . $item->id) }}" class="btn btn-outline-primary mt-auto">
                                    Lihat Detail
                                </a>
                            </div>

                        </div>
                    </div>
                @endforeach

                @if ($wisata->isEmpty())
                    <div class="col-12 text-center">
                        <p class="text-muted">
                            Belum ada wisata pada kategori ini.
                        </p>
                    </div>
                @endif

            </div>

            <div class="d-flex justify-content-center mt-5">
                {{ $wisata->links('vendor.pagination.bootstrap-4') }}
            </div>

        </div>
    </div>

    <style>
        .wisata-card {
            border-radius: 14px;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .wisata-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }

        .wisata-card img {
            transition: transform 0.4s ease;
        }

        .wisata-card:hover img {
            transform: scale(1.06);
        }
    </style>
@endsection
