@extends('layouts.home')

@section('content')
    {{-- HEADER --}}
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-4">
                Struktur Organisasi
            </h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="{{ url('/') }}">Home</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        Struktur Organisasi
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    {{-- CONTENT --}}
    <div class="container-xxl py-5">
        <div class="container">

            {{-- JUDUL --}}
            <div class="text-center mb-5">
                <h6 class="text-primary text-uppercase">
                    Visit Cianjur
                </h6>
                <h1 class="display-6 fw-bold">
                    Susunan Struktur Organisasi
                </h1>
                <p class="text-muted">
                    Tim pengelola dan pengembang Website Resmi Pariwisata Cianjur
                </p>
            </div>

            <div class="row g-4 justify-content-center">

                @foreach ($strukturorganisasi as $item)
                    <div class="col-lg-4 col-md-6">
                        <div class="card h-100 border-0 shadow-sm text-center struktur-card">

                            {{-- FOTO --}}
                            <div class="position-relative overflow-hidden">
                                <img src="{{ asset('storage/strukturorganisasi/' . $item->foto) }}" class="w-100"
                                    style="height: 320px; object-fit: cover;" alt="{{ $item->nama }}">

                                <div class="overlay"></div>
                            </div>

                            {{-- BODY --}}
                            <div class="card-body">
                                <h5 class="fw-bold mb-1">
                                    {{ $item->nama }}
                                </h5>
                                <span class="badge bg-primary">
                                    {{ $item->jabatan }}
                                </span>
                            </div>

                        </div>
                    </div>
                @endforeach

                @if ($strukturorganisasi->isEmpty())
                    <div class="col-12 text-center">
                        <p class="text-muted">
                            Data struktur organisasi belum tersedia.
                        </p>
                    </div>
                @endif

            </div>

            {{-- PAGINATION --}}
            <div class="d-flex justify-content-center mt-5">
                {{ $strukturorganisasi->links('vendor.pagination.bootstrap-4') }}
            </div>

        </div>
    </div>

    {{-- STYLE KHUSUS --}}
    <style>
        .struktur-card {
            transition: all 0.3s ease;
            border-radius: 12px;
            overflow: hidden;
        }

        .struktur-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }

        .struktur-card .overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.5), transparent);
        }

        .struktur-card img {
            transition: transform 0.4s ease;
        }

        .struktur-card:hover img {
            transform: scale(1.05);
        }
    </style>
@endsection
