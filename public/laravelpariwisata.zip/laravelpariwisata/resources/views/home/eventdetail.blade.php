@extends('layouts.home')

@section('content')
    {{-- HEADER --}}
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-5 text-white animated slideInDown mb-3">
                {{ $event->judul }}
            </h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="{{ url('/') }}">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a class="text-white" href="{{ url('/event') }}">Event</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        Detail Event
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    {{-- CONTENT --}}
    <div class="container-xxl py-5">
        <div class="container">

            <div class="row g-5 align-items-start">

                {{-- POSTER --}}
                <div class="col-lg-5">
                    <div class="event-image shadow-sm">
                        <img src="{{ asset('storage/poster/' . $event->poster) }}" alt="{{ $event->judul }}">

                        <span class="badge bg-success position-absolute m-3">
                            {{ ucfirst($event->status) }}
                        </span>
                    </div>
                </div>

                {{-- DETAIL --}}
                <div class="col-lg-7">
                    <h6 class="text-primary text-uppercase mb-2">
                        Visit Cianjur
                    </h6>

                    <h1 class="fw-bold mb-3">
                        {{ $event->judul }}
                    </h1>

                    <div class="row g-3 mb-4">

                        <div class="col-md-6">
                            <div class="info-box">
                                <i class="fa fa-calendar-alt text-primary mb-2"></i>
                                <p class="mb-0 fw-semibold">Tanggal Event</p>
                                <small class="text-muted">
                                    {{ date('d M Y', strtotime($event->tanggalmulai)) }}
                                    -
                                    {{ date('d M Y', strtotime($event->tanggalselesai)) }}
                                </small>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="info-box">
                                <i class="fa fa-map-marker-alt text-primary mb-2"></i>
                                <p class="mb-0 fw-semibold">Lokasi</p>
                                <small class="text-muted">
                                    {{ $event->lokasi }}
                                </small>
                            </div>
                        </div>

                    </div>

                    <div class="mb-4">
                        {!! $event->deskripsi !!}
                    </div>

                    <a href="{{ url('/event') }}" class="btn btn-outline-primary px-4">
                        <i class="fa fa-arrow-left me-2"></i>
                        Kembali ke Event
                    </a>
                </div>

            </div>

        </div>
    </div>

    {{-- STYLE --}}
    <style>
        .event-image {
            position: relative;
            border-radius: 16px;
            overflow: hidden;
        }

        .event-image img {
            width: 100%;
            height: 460px;
            object-fit: cover;
            transition: transform .4s ease;
        }

        .event-image:hover img {
            transform: scale(1.06);
        }

        .info-box {
            border: 1px solid #eee;
            border-radius: 14px;
            padding: 18px;
            text-align: center;
            background: #fff;
            transition: all .3s ease;
        }

        .info-box:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, .08);
        }
    </style>
@endsection
