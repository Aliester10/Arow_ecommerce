<?php

namespace App\Providers;

use App\Models\KategoriModel;
use App\Models\WebsiteModel;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $settingwebsite = WebsiteModel::findOrFail(1);
        $globalkategoriwisata = KategoriModel::orderBy('nama', 'ASC')->get();
        View::share([
            'settingwebsite' => $settingwebsite,
            'globalkategoriwisata' => $globalkategoriwisata,
        ]);
    }
}
