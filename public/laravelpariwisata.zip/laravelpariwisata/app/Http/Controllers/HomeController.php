<?php

namespace App\Http\Controllers;

use App\Models\ArtikelModel;
use App\Models\EventModel;
use App\Models\GaleriModel;
use App\Models\HeroModel;
use App\Models\KategoriModel;
use App\Models\PengumumanModel;
use App\Models\StrukturorganisasiModel;
use App\Models\WisatafotoModel;
use App\Models\WisataModel;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $data['hero'] = HeroModel::orderBy('id', 'DESC')->limit(5)->get();
        return view('home.home', $data);
    }

    public function tentang()
    {
        return view('home.tentang');
    }

    public function visimisi()
    {
        return view('home.visimisi');
    }

    public function strukturorganisasi()
    {
        $data['strukturorganisasi'] = StrukturorganisasiModel::orderBy('id', 'ASC')->paginate(9);
        return view('home.strukturorganisasi', $data);
    }

    public function kategori($id)
    {
        $kategori = KategoriModel::findOrFail($id);

        $data['kategori'] = $kategori;
        $data['wisata'] = WisataModel::where('kategori_id', $id)
            ->orderBy('id', 'DESC')
            ->paginate(9);

        return view('home.kategori', $data);
    }

    public function wisatadetail($id)
    {
        $wisata = WisataModel::with('kategori')->findOrFail($id);
        $fotos = WisatafotoModel::where('wisata_id', $id)->get();

        return view('home.wisatadetail', compact('wisata', 'fotos'));
    }

    public function event()
    {
        $data['event'] = EventModel::orderBy('id', 'DESC')->paginate(9);
        return view('home.event', $data);
    }

    public function eventdetail($id)
    {
        $event = EventModel::findOrFail($id);
        return view('home.eventdetail', compact('event'));
    }

    public function artikel()
    {
        $data['artikel'] = ArtikelModel::with(['kategoriartikel', 'publishedby'])->orderBy('id', 'DESC')->paginate(9);
        return view('home.artikel', $data);
    }

    public function artikeldetail($id)
    {
        $artikel = ArtikelModel::with(['kategoriartikel', 'publishedby'])->findOrFail($id);
        return view('home.artikeldetail', compact('artikel'));
    }

    public function galeri()
    {
        $data['galeri'] = GaleriModel::orderBy('id', 'DESC')->paginate(12);
        return view('home.galeri', $data);
    }

    public function pengumuman()
    {
        $data['pengumuman'] = PengumumanModel::orderBy('id', 'DESC')->paginate(9);
        return view('home.pengumuman', $data);
    }

    public function pengumumandetail($id)
    {
        $pengumuman = PengumumanModel::findOrFail($id);
        return view('home.pengumumandetail', compact('pengumuman'));
    }
}
