<?php

namespace App\Http\Controllers;

use App\Models\ArtikelModel;
use App\Models\EventModel;
use App\Models\GaleriModel;
use App\Models\HeroModel;
use App\Models\KategoriartikelModel;
use App\Models\KategorigaleriModel;
use App\Models\KategoriModel;
use App\Models\PengumumanModel;
use App\Models\StrukturorganisasiModel;
use App\Models\User;
use App\Models\WebsiteModel;
use App\Models\WisatafotoModel;
use App\Models\WisataModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class PanelController extends Controller
{
    public function dashboard()
    {
        $user = User::findOrFail(Auth::user()->id);

        $totalWisata = WisataModel::count();
        $totalEvent = EventModel::count();
        $totalArtikel = ArtikelModel::count();
        $totalPengumuman = PengumumanModel::count();

        $wisataUnggulan = WisataModel::where('status', 'Aktif')
            ->orderBy('id', 'DESC')
            ->take(6)
            ->get();

        $eventTerdekat = EventModel::where('status', 'Aktif')
            ->whereDate('tanggalselesai', '>=', now())
            ->orderBy('tanggalmulai')
            ->take(6)
            ->get();

        $artikelTerbaru = ArtikelModel::where('status', 'Aktif')
            ->orderBy('id', 'DESC')
            ->take(6)
            ->get();

        return view('panel.dashboard', compact(
            'user',
            'totalWisata',
            'totalEvent',
            'totalArtikel',
            'totalPengumuman',
            'wisataUnggulan',
            'eventTerdekat',
            'artikelTerbaru'
        ));
    }

    // kategori
    public function kategori()
    {
        $data['kategori'] = KategoriModel::orderBy('id', 'DESC')->get();
        return view('panel.kategori', $data);
    }

    public function kategorisimpan(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
        ]);

        KategoriModel::create([
            'nama' => $request->nama,
        ]);

        return redirect('panel/kategori')->with('success', 'Data berhasil disimpan!');
    }

    public function kategoriedit($id)
    {
        $data['kategori'] = KategoriModel::findOrFail($id);
        return view('panel.kategoriedit', $data);
    }

    public function kategoriupdate(Request $request, $id)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
        ]);

        KategoriModel::where('id', $id)->update([
            'nama' => $request->nama,
        ]);

        return redirect('panel/kategori')->with('success', 'Data berhasil diupdate!');
    }

    public function kategorihapus($id)
    {
        KategoriModel::where('id', $id)->delete();
        return redirect('panel/kategori')->with('success', 'Data berhasil dihapus!');
    }

    // wisata
    public function wisata()
    {
        $data['wisata'] = WisataModel::with(['kategori', 'wisatafoto'])
            ->orderBy('id', 'DESC')
            ->get();

        $data['kategori'] = KategoriModel::orderBy('nama')->get();

        return view('panel.wisata', $data);
    }

    public function wisatatambah()
    {
        $data['kategori'] = KategoriModel::orderBy('nama')->get();
        return view('panel.wisatatambah', $data);
    }

    public function wisatasimpan(Request $request)
    {
        $request->validate([
            'kategori_id' => 'required',
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'alamat' => 'required|string',
            'desa' => 'required|string',
            'kecamatan' => 'required|string',
            'hargatiket' => 'required|numeric',
            'lat' => 'required',
            'lng' => 'required',
            'thumbnail' => 'image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
            'wisatafoto.*' => 'image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
            'jambuka' => 'required|date_format:H:i',
            'jamtutup' => 'required|date_format:H:i',
            'status' => 'required',
        ]);

        DB::beginTransaction();
        try {
            if ($request->hasFile('thumbnail')) {
                $thumbnailName = $request->file('thumbnail')->hashName();
                $request->file('thumbnail')->storeAs('thumbnail', $thumbnailName, 'public');
            } else {
                $thumbnailName = null;
            }

            $wisata = WisataModel::create([
                'kategori_id' => $request->kategori_id,
                'judul' => $request->judul,
                'deskripsi' => $request->deskripsi,
                'alamat' => $request->alamat,
                'desa' => $request->desa,
                'kecamatan' => $request->kecamatan,
                'hargatiket' => $request->hargatiket,
                'lat' => $request->lat,
                'lng' => $request->lng,
                'thumbnail' => $thumbnailName,
                'jambuka' => $request->jambuka,
                'jamtutup' => $request->jamtutup,
                'status' => $request->status,
            ]);

            if ($request->hasFile('wisatafoto')) {
                foreach ($request->file('wisatafoto') as $foto) {
                    $nama = $foto->hashName();
                    $foto->storeAs('wisatafoto', $nama, 'public');

                    WisatafotoModel::create([
                        'wisata_id' => $wisata->id,
                        'foto' => $nama
                    ]);
                }
            }
            DB::commit();
        } catch (\Throwable $th) {
            DB::rollBack();
            return back()->with('error', 'Terjadi kesalahan saat menyimpan data: ' . $th->getMessage());
        }

        return redirect('panel/wisata')->with('success', 'Data berhasil disimpan!');
    }

    public function wisataedit($id)
    {
        $data['wisata'] = WisataModel::with(['kategori', 'wisatafoto'])->findOrFail($id);
        $data['kategori'] = KategoriModel::orderBy('nama')->get();
        return view('panel.wisataedit', $data);
    }

    public function wisataupdate(Request $request, $id)
    {
        $request->validate([
            'kategori_id' => 'required',
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'alamat' => 'required|string',
            'desa' => 'required|string',
            'kecamatan' => 'required|string',
            'hargatiket' => 'required|numeric',
            'lat' => 'required',
            'lng' => 'required',
            'thumbnail' => 'nullable|image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
            'jambuka' => 'required|date_format:H:i',
            'jamtutup' => 'required|date_format:H:i',
            'status' => 'required',
        ]);

        $data = [
            'kategori_id' => $request->kategori_id,
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi,
            'alamat' => $request->alamat,
            'desa' => $request->desa,
            'kecamatan' => $request->kecamatan,
            'hargatiket' => $request->hargatiket,
            'lat' => $request->lat,
            'lng' => $request->lng,
            'jambuka' => $request->jambuka,
            'jamtutup' => $request->jamtutup,
            'status' => $request->status,
        ];

        if ($request->hasFile('thumbnail')) {
            $wisata = WisataModel::findOrFail($id);
            if ($wisata->thumbnail && file_exists(storage_path('app/public/thumbnail/' . $wisata->thumbnail))) {
                unlink(storage_path('app/public/thumbnail/' . $wisata->thumbnail));
            }
            $thumbnailName = $request->file('thumbnail')->hashName();
            $request->file('thumbnail')->storeAs('thumbnail', $thumbnailName, 'public');

            $data['thumbnail'] = $thumbnailName;
        }

        WisataModel::where('id', $id)->update($data);

        return redirect('panel/wisata')->with('success', 'Data berhasil diupdate!');
    }

    public function wisatafotosimpan(Request $request, $id)
    {
        $request->validate([
            'wisatafoto.*' => 'image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048'
        ]);

        if ($request->hasFile('wisatafoto')) {
            foreach ($request->file('wisatafoto') as $foto) {
                $nama = $foto->hashName();
                $foto->storeAs('wisatafoto', $nama, 'public');

                WisatafotoModel::create([
                    'wisata_id' => $id,
                    'foto' => $nama
                ]);
            }
        }

        return back()->with('success', 'Foto berhasil ditambahkan!');
    }

    public function wisatafotohapus($id)
    {
        $wisatafoto = WisatafotoModel::findOrFail($id);
        if ($wisatafoto->foto && file_exists(storage_path('app/public/wisatafoto/' . $wisatafoto->foto))) {
            unlink(storage_path('app/public/wisatafoto/' . $wisatafoto->foto));
        }
        $wisatafoto->delete();
        return back()->with('success', 'Foto berhasil dihapus!');
    }

    public function wisatahapus($id)
    {
        $wisata = WisataModel::findOrFail($id);

        if ($wisata->thumbnail && file_exists(storage_path('app/public/thumbnail/' . $wisata->thumbnail))) {
            unlink(storage_path('app/public/thumbnail/' . $wisata->thumbnail));
        }

        $fotos = WisatafotoModel::where('wisata_id', $id)->get();
        foreach ($fotos as $foto) {
            if ($foto->foto && file_exists(storage_path('app/public/wisatafoto/' . $foto->foto))) {
                unlink(storage_path('app/public/wisatafoto/' . $foto->foto));
            }
            $foto->delete();
        }

        $wisata->delete();

        return redirect('panel/wisata')->with('success', 'Data berhasil dihapus!');
    }

    // event
    public function event()
    {
        $data['event'] = EventModel::orderBy('id', 'DESC')
            ->get();
        return view('panel.event', $data);
    }

    public function eventtambah()
    {
        return view('panel.eventtambah');
    }

    public function eventsimpan(Request $request)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'tanggalmulai' => 'required|date',
            'tanggalselesai' => 'required|date',
            'lokasi' => 'required|string|max:255',
            'poster' => 'image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
            'deskripsi' => 'required|string',
            'status' => 'required',
        ]);

        if ($request->hasFile('poster')) {
            $posterName = $request->file('poster')->hashName();
            $request->file('poster')->storeAs('poster', $posterName, 'public');
        } else {
            $posterName = null;
        }

        EventModel::create([
            'judul' => $request->judul,
            'tanggalmulai' => $request->tanggalmulai,
            'tanggalselesai' => $request->tanggalselesai,
            'lokasi' => $request->lokasi,
            'poster' => $posterName,
            'deskripsi' => $request->deskripsi,
            'status' => $request->status,
        ]);

        return redirect('panel/event')->with('success', 'Data berhasil disimpan!');
    }

    public function eventedit($id)
    {
        $data['event'] = EventModel::findOrFail($id);
        return view('panel.eventedit', $data);
    }

    public function eventupdate(Request $request, $id)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'tanggalmulai' => 'required|date',
            'tanggalselesai' => 'required|date',
            'lokasi' => 'required|string|max:255',
            'poster' => 'nullable|image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
            'deskripsi' => 'required|string',
            'status' => 'required',
        ]);

        $event = EventModel::findOrFail($id);
        $data = [
            'judul' => $request->judul,
            'tanggalmulai' => $request->tanggalmulai,
            'tanggalselesai' => $request->tanggalselesai,
            'lokasi' => $request->lokasi,
            'deskripsi' => $request->deskripsi,
            'status' => $request->status,
        ];

        if ($request->hasFile('poster')) {
            if ($event->poster && file_exists(storage_path('app/public/poster/' . $event->poster))) {
                unlink(storage_path('app/public/poster/' . $event->poster));
            }
            $posterName = $request->file('poster')->hashName();
            $request->file('poster')->storeAs('poster', $posterName, 'public');
            $data['poster'] = $posterName;
        }

        EventModel::where('id', $id)->update($data);

        return redirect('panel/event')->with('success', 'Data berhasil diupdate!');
    }

    public function eventhapus($id)
    {
        $event = EventModel::findOrFail($id);
        if ($event->poster && file_exists(storage_path('app/public/poster/' . $event->poster))) {
            unlink(storage_path('app/public/poster/' . $event->poster));
        }
        $event->delete();
        return redirect('panel/event')->with('success', 'Data berhasil dihapus!');
    }

    // kategoriartikel
    public function kategoriartikel()
    {
        $data['kategori'] = KategoriartikelModel::orderBy('id', 'DESC')
            ->get();
        return view('panel.kategoriartikel', $data);
    }

    public function kategoriartikelsimpan(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
        ]);

        KategoriartikelModel::create([
            'nama' => $request->nama,
        ]);

        return redirect('panel/kategoriartikel')->with('success', 'Data berhasil disimpan!');
    }

    public function kategoriartikeledit($id)
    {
        $data['kategori'] = KategoriartikelModel::findOrFail($id);
        return view('panel.kategoriartikeledit', $data);
    }

    public function kategoriartikelupdate(Request $request, $id)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
        ]);

        KategoriartikelModel::where('id', $id)->update([
            'nama' => $request->nama,
        ]);

        return redirect('panel/kategoriartikel')->with('success', 'Data berhasil diupdate!');
    }

    public function kategoriartikelhapus($id)
    {
        KategoriartikelModel::where('id', $id)->delete();
        return redirect('panel/kategoriartikel')->with('success', 'Data berhasil dihapus!');
    }

    // artikel
    public function artikel()
    {
        $data['artikel'] = ArtikelModel::orderBy('id', 'DESC')
            ->get();
        return view('panel.artikel', $data);
    }

    public function artikeltambah()
    {
        $data['kategoriartikel'] = KategoriartikelModel::orderBy('nama')->get();
        return view('panel.artikeltambah', $data);
    }

    public function artikelsimpan(Request $request)
    {
        $request->validate([
            'kategoriartikel_id' => 'required',
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'thumbnail' => 'image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
            'status' => 'required',
        ]);

        if ($request->hasFile('thumbnail')) {
            $thumbnailName = $request->file('thumbnail')->hashName();
            $request->file('thumbnail')->storeAs('artikel', $thumbnailName, 'public');
        } else {
            $thumbnailName = null;
        }

        ArtikelModel::create([
            'kategoriartikel_id' => $request->kategoriartikel_id,
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi,
            'thumbnail' => $thumbnailName,
            'published_by' => Auth::user()->id,
            'status' => $request->status,
        ]);

        return redirect('panel/artikel')->with('success', 'Data berhasil disimpan!');
    }

    public function artikeledit($id)
    {
        $data['artikel'] = ArtikelModel::findOrFail($id);
        $data['kategoriartikel'] = KategoriartikelModel::orderBy('nama')->get();
        return view('panel.artikeledit', $data);
    }

    public function artikelupdate(Request $request, $id)
    {
        $request->validate([
            'kategoriartikel_id' => 'required',
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'thumbnail' => 'image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
            'status' => 'required',
        ]);

        $artikel = ArtikelModel::findOrFail($id);

        $data = [
            'kategoriartikel_id' => $request->kategoriartikel_id,
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi,
            'published_by' => Auth::user()->id,
            'status' => $request->status,
        ];

        if ($request->hasFile('thumbnail')) {
            if ($artikel->thumbnail && file_exists(storage_path('app/public/artikel/' . $artikel->thumbnail))) {
                unlink(storage_path('app/public/artikel/' . $artikel->thumbnail));
            }
            $thumbnailName = $request->file('thumbnail')->hashName();
            $request->file('thumbnail')->storeAs('artikel', $thumbnailName, 'public');
            $data['thumbnail'] = $thumbnailName;
        }

        ArtikelModel::where('id', $id)->update($data);

        return redirect('panel/artikel')->with('success', 'Data berhasil diupdate!');
    }

    public function artikelhapus($id)
    {
        $artikel = ArtikelModel::findOrFail($id);
        if ($artikel->thumbnail && file_exists(storage_path('app/public/artikel/' . $artikel->thumbnail))) {
            unlink(storage_path('app/public/artikel/' . $artikel->thumbnail));
        }
        $artikel->delete();
        return redirect('panel/artikel')->with('success', 'Data berhasil dihapus!');
    }

    // kategorigaleri
    public function kategorigaleri()
    {
        $data['kategori'] = KategorigaleriModel::orderBy('id', 'DESC')
            ->get();
        return view('panel.kategorigaleri', $data);
    }

    public function kategorigalerisimpan(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
        ]);

        KategorigaleriModel::create([
            'nama' => $request->nama,
        ]);

        return redirect('panel/kategorigaleri')->with('success', 'Data berhasil disimpan!');
    }

    public function kategorigaleriedit($id)
    {
        $data['kategori'] = KategorigaleriModel::findOrFail($id);
        return view('panel.kategorigaleriedit', $data);
    }

    public function kategorigaleriupdate(Request $request, $id)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
        ]);

        KategorigaleriModel::where('id', $id)->update([
            'nama' => $request->nama,
        ]);

        return redirect('panel/kategorigaleri')->with('success', 'Data berhasil diupdate!');
    }

    public function kategorigalerihapus($id)
    {
        KategorigaleriModel::where('id', $id)->delete();
        return redirect('panel/kategorigaleri')->with('success', 'Data berhasil dihapus!');
    }

    // galeri
    public function galeri()
    {
        $data['galeri'] = GaleriModel::orderBy('id', 'DESC')
            ->get();
        return view('panel.galeri', $data);
    }

    public function galeritambah()
    {
        $data['kategorigaleri'] = KategorigaleriModel::orderBy('nama')->get();
        return view('panel.galeritambah', $data);
    }

    public function galerisimpan(Request $request)
    {
        $request->validate([
            'kategorigaleri_id' => 'required',
            'judul' => 'required|string|max:255',
            'tipe' => 'required|in:Gambar,Video',
            'file' => 'required|file|mimes:jpg,jpeg,png,gif,webp,svg,mp4,mov,avi|max:10240',
        ]);

        $data = [
            'kategorigaleri_id' => $request->kategorigaleri_id,
            'judul' => $request->judul,
            'tipe' => $request->tipe,
        ];

        if ($request->hasFile('file')) {
            $fileName = $request->file('file')->hashName();
            $request->file('file')->storeAs('galeri', $fileName, 'public');
            $data['file'] = $fileName;
        }

        GaleriModel::create($data);

        return redirect('panel/galeri')->with('success', 'Data berhasil disimpan!');
    }

    public function galeriedit($id)
    {
        $data['galeri'] = GaleriModel::findOrFail($id);
        $data['kategorigaleri'] = KategorigaleriModel::orderBy('nama')->get();
        return view('panel.galeriedit', $data);
    }

    public function galeriupdate(Request $request, $id)
    {
        $request->validate([
            'kategorigaleri_id' => 'required',
            'judul' => 'required|string|max:255',
            'tipe' => 'required|in:Gambar,Video',
            'file' => 'file|mimes:jpg,jpeg,png,gif,webp,svg,mp4,mov,avi|max:10240',
        ]);

        $data = [
            'kategorigaleri_id' => $request->kategorigaleri_id,
            'judul' => $request->judul,
            'tipe' => $request->tipe,
        ];

        $galeri = GaleriModel::findOrFail($id);

        if ($request->hasFile('file')) {
            if ($galeri->file && file_exists(storage_path('app/public/galeri/' . $galeri->file))) {
                unlink(storage_path('app/public/galeri/' . $galeri->file));
            }
            $fileName = $request->file('file')->hashName();
            $request->file('file')->storeAs('galeri', $fileName, 'public');
            $data['file'] = $fileName;
        }

        GaleriModel::where('id', $id)->update($data);

        return redirect('panel/galeri')->with('success', 'Data berhasil diupdate!');
    }

    public function galerihapus($id)
    {
        $galeri = GaleriModel::findOrFail($id);
        if ($galeri->file && file_exists(storage_path('app/public/galeri/' . $galeri->file))) {
            unlink(storage_path('app/public/galeri/' . $galeri->file));
        }
        $galeri->delete();
        return redirect('panel/galeri')->with('success', 'Data berhasil dihapus!');
    }

    // pengumuman
    public function pengumuman()
    {
        $data['pengumuman'] = PengumumanModel::orderBy('id', 'DESC')
            ->get();
        return view('panel.pengumuman', $data);
    }

    public function pengumumantambah()
    {
        return view('panel.pengumumantambah');
    }

    public function pengumumansimpan(Request $request)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'thumbnail' => 'required|image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
            'file' => 'nullable|mimes:pdf,doc,docx,txt|max:10240',
        ]);

        if ($request->hasFile('thumbnail')) {
            $thumbnailName = $request->file('thumbnail')->hashName();
            $request->file('thumbnail')->storeAs('pengumuman', $thumbnailName, 'public');
        } else {
            $thumbnailName = null;
        }

        if ($request->hasFile('file')) {
            $fileName = $request->file('file')->hashName();
            $request->file('file')->storeAs('pengumuman', $fileName, 'public');
        } else {
            $fileName = null;
        }

        PengumumanModel::create([
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi,
            'thumbnail' => $thumbnailName,
            'file' => $fileName,
        ]);

        return redirect('panel/pengumuman')->with('success', 'Data berhasil disimpan!');
    }

    public function pengumumanedit($id)
    {
        $data['pengumuman'] = PengumumanModel::findOrFail($id);
        return view('panel.pengumumanedit', $data);
    }

    public function pengumumanupdate(Request $request, $id)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'thumbnail' => 'nullable|image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
            'file' => 'nullable|mimes:pdf,doc,docx,txt|max:10240',
        ]);

        $pengumuman = PengumumanModel::findOrFail($id);

        $data = [
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi,
        ];

        if ($request->hasFile('thumbnail')) {
            if ($pengumuman->thumbnail && file_exists(storage_path('app/public/pengumuman/' . $pengumuman->thumbnail))) {
                unlink(storage_path('app/public/pengumuman/' . $pengumuman->thumbnail));
            }
            $thumbnailName = $request->file('thumbnail')->hashName();
            $request->file('thumbnail')->storeAs('pengumuman', $thumbnailName, 'public');
            $data['thumbnail'] = $thumbnailName;
        }

        if ($request->hasFile('file')) {
            if ($pengumuman->file && file_exists(storage_path('app/public/pengumuman/' . $pengumuman->file))) {
                unlink(storage_path('app/public/pengumuman/' . $pengumuman->file));
            }
            $fileName = $request->file('file')->hashName();
            $request->file('file')->storeAs('pengumuman', $fileName, 'public');
            $data['file'] = $fileName;
        }

        PengumumanModel::where('id', $id)->update($data);

        return redirect('panel/pengumuman')->with('success', 'Data berhasil diupdate!');
    }

    public function pengumumanhapus($id)
    {
        $pengumuman = PengumumanModel::findOrFail($id);
        if ($pengumuman->thumbnail && file_exists(storage_path('app/public/pengumuman/' . $pengumuman->thumbnail))) {
            unlink(storage_path('app/public/pengumuman/' . $pengumuman->thumbnail));
        }
        if ($pengumuman->file && file_exists(storage_path('app/public/pengumuman/' . $pengumuman->file))) {
            unlink(storage_path('app/public/pengumuman/' . $pengumuman->file));
        }
        $pengumuman->delete();
        return redirect('panel/pengumuman')->with('success', 'Data berhasil dihapus!');
    }

    // strukturorganisasi
    public function strukturorganisasi()
    {
        $data['strukturorganisasi'] = StrukturorganisasiModel::orderBy('id', 'DESC')->get();
        return view('panel.strukturorganisasi', $data);
    }

    public function strukturorganisasisimpan(Request $request)
    {
        $request->validate([
            'jabatan' => 'required|string|max:255',
            'nama' => 'required|string|max:255',
            'foto' => 'required|image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
        ]);

        if ($request->hasFile('foto')) {
            $fotoName = $request->file('foto')->hashName();
            $request->file('foto')->storeAs('strukturorganisasi', $fotoName, 'public');
        } else {
            $fotoName = null;
        }

        StrukturorganisasiModel::create([
            'jabatan' => $request->jabatan,
            'nama' => $request->nama,
            'foto' => $fotoName,
        ]);

        return redirect('panel/strukturorganisasi')->with('success', 'Data berhasil disimpan!');
    }

    public function strukturorganisasiedit($id)
    {
        $data['strukturorganisasi'] = StrukturorganisasiModel::findOrFail($id);
        return view('panel.strukturorganisasiedit', $data);
    }

    public function strukturorganisasiupdate(Request $request, $id)
    {
        $request->validate([
            'jabatan' => 'required|string|max:255',
            'nama' => 'required|string|max:255',
            'foto' => 'nullable|image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
        ]);

        $strukturorganisasi = StrukturorganisasiModel::findOrFail($id);

        $data = [
            'jabatan' => $request->jabatan,
            'nama' => $request->nama,
        ];

        if ($request->hasFile('foto')) {
            if ($strukturorganisasi->foto && file_exists(storage_path('app/public/strukturorganisasi/' . $strukturorganisasi->foto))) {
                unlink(storage_path('app/public/strukturorganisasi/' . $strukturorganisasi->foto));
            }
            $fotoName = $request->file('foto')->hashName();
            $request->file('foto')->storeAs('strukturorganisasi', $fotoName, 'public');
            $data['foto'] = $fotoName;
        }

        StrukturorganisasiModel::where('id', $id)->update($data);

        return redirect('panel/strukturorganisasi')->with('success', 'Data berhasil diupdate!');
    }

    public function strukturorganisahapus($id)
    {
        $strukturorganisasi = StrukturorganisasiModel::findOrFail($id);
        if ($strukturorganisasi->foto && file_exists(storage_path('app/public/strukturorganisasi/' . $strukturorganisasi->foto))) {
            unlink(storage_path('app/public/strukturorganisasi/' . $strukturorganisasi->foto));
        }
        $strukturorganisasi->delete();
        return redirect('panel/strukturorganisasi')->with('success', 'Data berhasil dihapus!');
    }

    // hero
    public function hero()
    {
        $data['hero'] = HeroModel::orderBy('id', 'DESC')->get();
        return view('panel.hero', $data);
    }

    public function herosimpan(Request $request)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'foto' => 'required|image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
        ]);

        if ($request->hasFile('foto')) {
            $fotoName = $request->file('foto')->hashName();
            $request->file('foto')->storeAs('hero', $fotoName, 'public');
        } else {
            $fotoName = null;
        }

        HeroModel::create([
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi,
            'foto' => $fotoName,
        ]);

        return redirect('panel/hero')->with('success', 'Data berhasil disimpan!');
    }

    public function heroedit($id)
    {
        $data['hero'] = HeroModel::findOrFail($id);
        return view('panel.heroedit', $data);
    }

    public function heroupdate(Request $request, $id)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'foto' => 'nullable|image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
        ]);

        $hero = HeroModel::findOrFail($id);

        $data = [
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi,
        ];

        if ($request->hasFile('foto')) {
            if ($hero->foto && file_exists(storage_path('app/public/hero/' . $hero->foto))) {
                unlink(storage_path('app/public/hero/' . $hero->foto));
            }
            $fotoName = $request->file('foto')->hashName();
            $request->file('foto')->storeAs('hero', $fotoName, 'public');
            $data['foto'] = $fotoName;
        }

        HeroModel::where('id', $id)->update($data);

        return redirect('panel/hero')->with('success', 'Data berhasil diupdate!');
    }

    public function herohapus($id)
    {
        $hero = HeroModel::findOrFail($id);
        if ($hero->foto && file_exists(storage_path('app/public/hero/' . $hero->foto))) {
            unlink(storage_path('app/public/hero/' . $hero->foto));
        }
        $hero->delete();
        return redirect('panel/hero')->with('success', 'Data berhasil dihapus!');
    }

    // website
    public function website()
    {
        $data['website'] = WebsiteModel::findOrFail(1);
        return view('panel.website', $data);
    }

    public function websiteupdate(Request $request)
    {
        $request->validate([
            'namaweb' => 'required|string|max:255',
            'tentang' => 'required|string',
            'logo' => 'nullable|image|mimes:jpg,jpeg,png,gif,webp,svg|max:2048',
            'visi' => 'required|string',
            'misi' => 'required|string',
            'email' => 'required|email|max:255',
            'nohp' => 'required|string|max:20',
        ]);

        $website = WebsiteModel::findOrFail(1);

        $data = [
            'namaweb' => $request->namaweb,
            'tentang' => $request->tentang,
            'visi' => $request->visi,
            'misi' => $request->misi,
            'email' => $request->email,
            'nohp' => $request->nohp,
        ];

        if ($request->hasFile('logo')) {
            if ($website->logo && file_exists(storage_path('app/public/website/' . $website->logo))) {
                unlink(storage_path('app/public/website/' . $website->logo));
            }
            $logoName = $request->file('logo')->hashName();
            $request->file('logo')->storeAs('website', $logoName, 'public');
            $data['logo'] = $logoName;
        }


        WebsiteModel::where('id', 1)->update($data);

        return redirect('panel/website')->with('success', 'Data berhasil diupdate!');
    }

    // profile
    public function profile()
    {
        $data['profile'] = User::findOrFail(Auth::user()->id);
        return view('panel.profile', $data);
    }

    public function profileupdate(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'password' => 'nullable|string|min:8|confirmed',
        ]);

        $user = User::findOrFail(Auth::user()->id);

        $data = [
            'name' => $request->name,
            'email' => $request->email,
        ];

        if (!empty($request->password)) {
            $data['password'] = Hash::make($request->password);
        }

        User::where('id', Auth::user()->id)->update($data);

        return redirect('panel/profile')->with('success', 'Data berhasil diupdate!');
    }
}
