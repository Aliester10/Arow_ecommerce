<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WisataModel extends Model
{
    protected $table = 'wisata';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $guarded = [];

    public function kategori()
    {
        return $this->belongsTo(KategoriModel::class, 'kategori_id');
    }

    public function wisatafoto()
    {
        return $this->hasMany(WisatafotoModel::class, 'wisata_id');
    }
}
