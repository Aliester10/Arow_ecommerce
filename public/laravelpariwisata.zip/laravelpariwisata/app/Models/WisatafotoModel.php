<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WisatafotoModel extends Model
{
    protected $table = 'wisatafoto';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $guarded = [];

    public function wisata()
    {
        return $this->belongsTo(WisataModel::class, 'wisata_id');
    }
}
