<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KategorigaleriModel extends Model
{
    protected $table = 'kategorigaleri';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $guarded = [];
}
