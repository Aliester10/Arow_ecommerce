<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HeroModel extends Model
{
    protected $table = 'hero';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $guarded = [];
}
