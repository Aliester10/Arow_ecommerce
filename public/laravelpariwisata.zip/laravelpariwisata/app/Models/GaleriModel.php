<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GaleriModel extends Model
{
    protected $table = 'galeri';
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $guarded = [];

    public function kategorigaleri()
    {
        return $this->belongsTo(KategorigaleriModel::class, 'kategorigaleri_id', 'id');
    }
}
