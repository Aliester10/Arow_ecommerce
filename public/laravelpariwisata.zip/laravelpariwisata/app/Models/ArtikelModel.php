<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ArtikelModel extends Model
{
    protected $table = 'artikel';
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $guarded = [];

    public function kategoriartikel()
    {
        return $this->belongsTo(KategoriartikelModel::class, 'kategoriartikel_id', 'id');
    }

    public function publishedby()
    {
        return $this->belongsTo(User::class, 'published_by', 'id');
    }
}
