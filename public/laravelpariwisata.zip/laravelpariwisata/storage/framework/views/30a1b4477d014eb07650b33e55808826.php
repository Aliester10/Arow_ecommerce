<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">

            
            <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div class="flex-grow-1">
                    <h3 class="fw-bold mb-2 mb-md-0 text-center text-md-start">
                        Manajemen Galeri
                    </h3>
                </div>

                <div class="d-flex flex-wrap justify-content-center justify-content-md-end gap-2">
                    <a href="<?php echo e(url('panel/galeritambah')); ?>" class="btn btn-primary">
                        <i class="fa fa-plus me-1"></i> Tambah Galeri
                    </a>
                </div>
            </div>

            
            <div class="card mt-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle w-100" id="datatable">
                            <thead class="table-primary text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Judul</th>
                                    <th>Kategori</th>
                                    <th>Tipe</th>
                                    <th>File</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($value->judul); ?></td>
                                        <td><?php echo e($value->kategorigaleri->nama ?? '-'); ?></td>
                                        <td><?php echo e($value->tipe); ?></td>
                                        <td class="text-center">
                                            <?php if($value->file): ?>
                                                <a href="<?php echo e(asset('storage/galeri/' . $value->file)); ?>" target="_blank">
                                                    Lihat File
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">

                                            <a href="<?php echo e(url('panel/galeriedit/' . $value->id)); ?>"
                                                class="btn btn-sm btn-warning">
                                                <i class="fa fa-edit"></i>
                                            </a>

                                            <form action="<?php echo e(url('panel/galerihapus/' . $value->id)); ?>" method="POST"
                                                class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Hapus galeri ini?')">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/panel/galeri.blade.php ENDPATH**/ ?>