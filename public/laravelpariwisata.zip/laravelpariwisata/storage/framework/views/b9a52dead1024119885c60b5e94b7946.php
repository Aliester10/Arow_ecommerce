<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-4">
                Artikel
            </h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        Artikel
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    
    <div class="container-xxl py-5">
        <div class="container">

            
            <div class="text-center mb-5">
                <h6 class="text-primary text-uppercase">
                    Visit Cianjur
                </h6>
                <h1 class="display-6 fw-bold">
                    Artikel & Informasi
                </h1>
                <p class="text-muted">
                    Informasi seputar pariwisata, budaya, event, dan berita terbaru di Cianjur
                </p>
            </div>

            
            <div class="row g-4">

                <?php $__empty_1 = true; $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="card artikel-card h-100 border-0 shadow-sm">

                            
                            <div class="position-relative overflow-hidden">
                                <img src="<?php echo e(asset('storage/artikel/' . $item->thumbnail)); ?>" class="w-100 artikel-thumb"
                                    alt="<?php echo e($item->judul); ?>">

                                <span class="badge bg-primary position-absolute top-0 start-0 m-3">
                                    <?php echo e($item->kategoriartikel->nama ?? 'Artikel'); ?>

                                </span>
                            </div>

                            
                            <div class="card-body d-flex flex-column">

                                <small class="text-muted mb-2">
                                    <i class="fa fa-calendar me-1"></i>
                                    <?php echo e(date('d M Y', strtotime($item->created_at))); ?>

                                    <span class="mx-1">•</span>
                                    <i class="fa fa-user me-1"></i>
                                    <?php echo e($item->publishedby->name ?? 'Admin'); ?>

                                </small>

                                <h5 class="fw-bold mb-3">
                                    <?php echo e($item->judul); ?>

                                </h5>

                                <p class="text-muted mb-4">
                                    <?php echo e(Str::limit(strip_tags($item->deskripsi), 110)); ?>

                                </p>

                                <a href="<?php echo e(url('artikeldetail/' . $item->id)); ?>" class="btn btn-outline-primary mt-auto">
                                    Baca Selengkapnya
                                </a>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center">
                        <p class="text-muted">
                            Belum ada artikel yang dipublikasikan.
                        </p>
                    </div>
                <?php endif; ?>

            </div>

            
            <div class="d-flex justify-content-center mt-5">
                <?php echo e($artikel->links('vendor.pagination.bootstrap-4')); ?>

            </div>

        </div>
    </div>

    
    <style>
        .artikel-card {
            border-radius: 16px;
            overflow: hidden;
            transition: all .3s ease;
        }

        .artikel-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }

        .artikel-thumb {
            height: 230px;
            object-fit: cover;
            transition: transform .4s ease;
        }

        .artikel-card:hover .artikel-thumb {
            transform: scale(1.07);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/home/artikel.blade.php ENDPATH**/ ?>