<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Login - Visit Cianjur</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body class="min-vh-100 d-flex align-items-center justify-content-center"
    style="background: linear-gradient(135deg, #1e3c72, #2a9d8f, #8d6e63);">

    <div class="card shadow-lg border-0 rounded-4 p-4" style="max-width: 400px; width: 100%;">

        <!-- Icon -->
        

        <!-- Title -->
        <h4 class="text-center fw-bold text-primary mb-0">Visit Cianjur</h4>
        <p class="text-center text-muted small mb-4">
            Sistem Informasi Bimbingan Konseling
        </p>

        <!-- Form -->
        <form action="<?php echo e(url('loginproses')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label small">Email</label>
                <input type="email" name="email" class="form-control form-control-lg" placeholder="Email">
            </div>

            <div class="mb-4">
                <label class="form-label small">Password</label>
                <input type="password" name="password" class="form-control form-control-lg" placeholder="••••••">
            </div>

            <button type="submit" class="btn btn-primary btn-lg w-100 fw-semibold">
                Login
            </button>

            

        </form>

    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: "success",
                title: "<?php echo e(session('success')); ?>",
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000
            });
        </script>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: "error",
                title: "<?php echo e(session('error')); ?>",
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000
            });
        </script>
    <?php endif; ?>

</body>

</html>
<?php /**PATH E:\Project Laravel\visicianjur-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>