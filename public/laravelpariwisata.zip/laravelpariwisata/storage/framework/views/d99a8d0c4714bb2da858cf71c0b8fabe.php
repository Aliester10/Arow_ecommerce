<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo e($settingwebsite->namaweb); ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('storage/website/' . $settingwebsite->logo)); ?>" type="image/x-icon" />

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&family=Poppins:wght@600;700&display=swap"
        rel="stylesheet" />

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset('assets/home')); ?>/lib/animate/animate.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/home')); ?>/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset('assets/home')); ?>/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Template Stylesheet -->
    <link href="<?php echo e(asset('assets/home')); ?>/css/style.css" rel="stylesheet" />

    <script src="<?php echo e(asset('assets/ckeditor/ckeditor.js')); ?>"></script>

    <?php
        $foto = asset('assets/home/img/carousel-1.jpg');
        if ($settingwebsite && $settingwebsite->logo) {
            $foto = asset('storage/website/' . $settingwebsite->logo);
        }
    ?>
    <style>
        .page-header {
            background: linear-gradient(rgba(0, 0, 0, .65), rgba(0, 0, 0, .65)), url(<?php echo e($foto); ?>) center center no-repeat;
            background-size: cover;
        }
    </style>

</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-grow text-success" role="status"></div>
    </div>
    <!-- Spinner End -->

    <!-- Topbar Start -->
    
    <!-- Topbar End -->

    <!-- Navbar Start -->


    <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top px-4 px-lg-5 py-lg-0">
        <a href="<?php echo e(url('/')); ?>" class="navbar-brand d-flex align-items-center">
            <h1 class="m-0">
                
                

                <?php echo e($settingwebsite->namaweb); ?>

            </h1>
        </a>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-3 py-lg-0">
                <a href="<?php echo e(url('/')); ?>"
                    class="nav-item nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>">Home</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Profil</a>
                    <div class="dropdown-menu bg-light m-0">
                        <a href="<?php echo e(url('tentang')); ?>" class="dropdown-item">Tentang</a>
                        <a href="<?php echo e(url('visimisi')); ?>" class="dropdown-item">Visi & Misi</a>
                        <a href="<?php echo e(url('strukturorganisasi')); ?>" class="dropdown-item">Struktur Organisasi</a>
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Destinasi Wisata</a>
                    <div class="dropdown-menu bg-light m-0">
                        <?php $__currentLoopData = $globalkategoriwisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('kategori/' . $value->id)); ?>"
                                class="dropdown-item"><?php echo e($value->nama); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <a href="<?php echo e(url('event')); ?>"
                    class="nav-item nav-link <?php echo e(Request::is('event*') ? 'active' : ''); ?>">Event & Budaya</a>
                <a href="<?php echo e(url('artikel')); ?>"
                    class="nav-item nav-link <?php echo e(Request::is('artikel*') ? 'active' : ''); ?>">Artikel</a>
                <a href="<?php echo e(url('galeri')); ?>"
                    class="nav-item nav-link <?php echo e(Request::is('galeri*') ? 'active' : ''); ?>">Galeri</a>
                <a href="<?php echo e(url('pengumuman')); ?>"
                    class="nav-item nav-link <?php echo e(Request::is('pengumuman*') ? 'active' : ''); ?>">Informasi Publik</a>
                <!-- Akun dropdown -->
            </div>
        </div>
    </nav>

    <!-- Navbar End -->

    <?php echo $__env->yieldContent('content'); ?>

    <!-- Footer Start -->
    <div class="container-fluid bg-dark footer mt-5 pt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">

                <!-- Kiri: Nama & Deskripsi -->
                <div class="col-lg-6 col-md-6">
                    <h1 class="text-white mb-4">
                        <?php echo e($settingwebsite->namaweb); ?>

                    </h1>
                    <p class="text-light">
                        <?php echo e($settingwebsite->namaweb); ?> adalah portal resmi pariwisata Cianjur, menyediakan informasi
                        terpercaya mengenai destinasi wisata, budaya, event, serta mendukung pelaku wisata lokal dan
                        transparansi informasi publik.
                    </p>

                    <div class="d-flex pt-3">
                        <a class="btn btn-square btn-outline-success me-2" href="https://instagram.com/visitcianjur"
                            target="_blank">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a class="btn btn-square btn-outline-success me-2" href="https://facebook.com/visitcianjur"
                            target="_blank">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a class="btn btn-square btn-outline-success me-2" href="https://youtube.com/@visitcianjur"
                            target="_blank">
                            <i class="fab fa-youtube"></i>
                        </a>
                        <a class="btn btn-square btn-outline-success me-0" href="https://wa.me/628123456789"
                            target="_blank">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                    </div>
                </div>


                <!-- Kanan: Kontak & Informasi -->
                <div class="col-lg-6 col-md-6">
                    <h4 class="text-light mb-4">Kontak & Informasi</h4>

                    <p class="text-light">
                        <i class="fa fa-map-marker-alt me-3"></i>
                        <?php echo e($settingwebsite->namaweb); ?>

                    </p>

                    <p class="text-light">
                        <i class="fa fa-phone-alt me-3"></i>
                        <?php echo e($settingwebsite->nohp); ?>

                    </p>

                    <p class="text-light">
                        <i class="fa fa-envelope me-3"></i>
                        <?php echo e($settingwebsite->email); ?>

                    </p>

                    <p class="text-light">
                        <i class="fa fa-lock me-3"></i>
                        Privasi dan kerahasiaan pengguna adalah prioritas kami
                    </p>
                </div>

            </div>
        </div>

        <!-- Copyright -->
        <div class="container-fluid copyright py-3">
            <div class="container text-center text-md-start">
                <div class="row">
                    <div class="col-md-6 text-light">
                        &copy; <?php echo e(date('Y')); ?>

                        <a class="text-success" href="#"><?php echo e($settingwebsite->namaweb); ?></a>.
                        All Rights Reserved.
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-success btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/home')); ?>/lib/wow/wow.min.js"></script>
    <script src="<?php echo e(asset('assets/home')); ?>/lib/easing/easing.min.js"></script>
    <script src="<?php echo e(asset('assets/home')); ?>/lib/waypoints/waypoints.min.js"></script>
    <script src="<?php echo e(asset('assets/home')); ?>/lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?php echo e(asset('assets/home')); ?>/js/main.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('success')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: "<?php echo e(session('success')); ?>"
            });
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "error",
                title: "<?php echo e(session('error')); ?>"
            });
        </script>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <script>
            let errorMessages = `
            <ul style="text-align:left;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        `;
            Swal.fire({
                icon: 'warning',
                title: 'Validasi Gagal',
                html: errorMessages,
                confirmButtonColor: '#f0ad4e',
                confirmButtonText: 'Perbaiki'
            });
        </script>
    <?php endif; ?>


    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/layouts/home.blade.php ENDPATH**/ ?>