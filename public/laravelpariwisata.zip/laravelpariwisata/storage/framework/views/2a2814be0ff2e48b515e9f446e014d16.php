<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">

            
            <div class="page-header d-flex justify-content-between align-items-center">
                <h3 class="fw-bold">Tambah Wisata</h3>
                <a href="<?php echo e(url('panel/wisata')); ?>" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            
            <div class="card mt-4">
                <div class="card-body">

                    <form action="<?php echo e(url('panel/wisatasimpan')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Judul Wisata</label>
                                <input type="text" name="judul" class="form-control" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Kategori</label>
                                <select name="kategori_id" class="form-control" required>
                                    <option value="">-- Pilih Kategori --</option>
                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Jam Buka</label>
                                <input type="time" name="jambuka" class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Jam Tutup</label>
                                <input type="time" name="jamtutup" class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Alamat</label>
                                <input type="text" name="alamat" class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Desa</label>
                                <input type="text" name="desa" class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Kecamatan</label>
                                <input type="text" name="kecamatan" class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" id="deskripsi" rows="3"></textarea>
                                <script>
                                    CKEDITOR.replace('deskripsi');
                                </script>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Harga Tiket</label>
                                <input type="number" name="hargatiket" class="form-control" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Koordinat</label>
                                <div class="d-flex gap-2">
                                    <input type="text" name="lat" id="lat" class="form-control" readonly
                                        placeholder="Latitude">
                                    <input type="text" name="lng" id="lng" class="form-control" readonly
                                        placeholder="Longitude">
                                </div>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Thumbnail</label>
                                <input type="file" name="thumbnail" class="form-control" accept="image/*" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Pilih Lokasi (Klik Peta)</label>
                                <div id="map" style="height: 400px; border-radius: 12px;"></div>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label>Status</label>
                                <select name="status" class="form-control" required>
                                    <option value="Aktif">Aktif</option>
                                    <option value="Non Aktif">Non Aktif</option>
                                </select>
                            </div>

                        </div>

                        <hr class="my-4">

                        <h5 class="fw-bold mb-3">Foto Wisata</h5>

                        <div class="table-responsive">
                            <table class="table table-bordered align-middle" id="fotoTable">
                                <thead class="table-light text-center">
                                    <tr>
                                        <th>Foto</th>
                                        <th width="100">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <input type="file" name="wisatafoto[]" class="form-control" accept="image/*"
                                                required>
                                        </td>
                                        <td class="text-center">
                                            <button type="button" class="btn btn-sm btn-success" onclick="addRow()">
                                                <i class="fa fa-plus"></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>


                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save me-1"></i> Simpan
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css">
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

    <script>
        let map, marker;

        document.addEventListener('DOMContentLoaded', function() {

            map = L.map('map');

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap'
            }).addTo(map);

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        const lat = position.coords.latitude.toFixed(6);
                        const lng = position.coords.longitude.toFixed(6);

                        map.setView([lat, lng], 14);
                        marker = L.marker([lat, lng]).addTo(map);

                        document.getElementById('lat').value = lat;
                        document.getElementById('lng').value = lng;
                    },
                    function() {
                        setDefaultLocation();
                    }
                );
            } else {
                setDefaultLocation();
            }

            map.on('click', function(e) {
                const lat = e.latlng.lat.toFixed(6);
                const lng = e.latlng.lng.toFixed(6);

                document.getElementById('lat').value = lat;
                document.getElementById('lng').value = lng;

                if (marker) {
                    marker.setLatLng(e.latlng);
                } else {
                    marker = L.marker(e.latlng).addTo(map);
                }
            });
        });

        function setDefaultLocation() {
            const lat = -6.8185;
            const lng = 107.1416;

            map.setView([lat, lng], 11);
            marker = L.marker([lat, lng]).addTo(map);

            document.getElementById('lat').value = lat;
            document.getElementById('lng').value = lng;
        }
    </script>

    <script>
        function addRow() {
            const table = document.getElementById('fotoTable').getElementsByTagName('tbody')[0];

            const row = table.insertRow();

            const cellFoto = row.insertCell(0);
            const cellAksi = row.insertCell(1);

            cellFoto.innerHTML = `
            <input type="file" name="wisatafoto[]" class="form-control" accept="image/*" required>
        `;

            cellAksi.classList.add('text-center');
            cellAksi.innerHTML = `
            <button type="button" class="btn btn-sm btn-danger" onclick="removeRow(this)">
                <i class="fa fa-minus"></i>
            </button>
        `;
        }

        function removeRow(btn) {
            const row = btn.closest('tr');
            row.remove();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/panel/wisatatambah.blade.php ENDPATH**/ ?>