<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white mb-4">Visi & Misi</h1>
            <nav>
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">Visi & Misi</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- VISI MISI -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5 align-items-center">

                <!-- GAMBAR / IDENTITAS -->
                <div class="col-lg-6">
                    <div class="position-relative overflow-hidden ps-5 pt-5 h-100" style="min-height: 420px;">
                        <img class="position-absolute w-100 h-100"
                            src="<?php echo e(asset('storage/website/' . $settingwebsite->logo)); ?>"
                            style="object-fit: cover; border-radius: 12px;">

                        <div class="position-absolute top-0 start-0 bg-white pe-3 pb-3 shadow"
                            style="width: 220px; height: 220px; border-radius:12px;">
                            <div class="d-flex flex-column justify-content-center text-center bg-primary h-100 p-3 rounded">
                                <h5 class="text-white mb-1"><?php echo e($settingwebsite->namaweb); ?></h5>
                                <small class="text-white opacity-75">Visit Cianjur</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- VISI & MISI -->
                <div class="col-lg-6">
                    <!-- VISI -->
                    <div class="mb-5">
                        <div class="d-flex align-items-center mb-3">
                            <i class="fa fa-eye fa-2x text-primary me-3"></i>
                            <h2 class="fw-bold mb-0">Visi</h2>
                        </div>

                        <div class="p-4 bg-light rounded shadow-sm">
                            <div class="fs-6 lh-lg">
                                <?php echo $settingwebsite->visi; ?>

                            </div>
                        </div>
                    </div>

                    <!-- MISI -->
                    <div>
                        <div class="d-flex align-items-center mb-3">
                            <i class="fa fa-bullseye fa-2x text-primary me-3"></i>
                            <h2 class="fw-bold mb-0">Misi</h2>
                        </div>

                        <div class="p-4 bg-light rounded shadow-sm misi-list">
                            <?php echo $settingwebsite->misi; ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- STYLE KHUSUS MISI -->
    <style>
        .misi-list ol {
            padding-left: 0;
            list-style: none;
            counter-reset: misi;
        }

        .misi-list ol li {
            counter-increment: misi;
            position: relative;
            padding: 15px 15px 15px 60px;
            margin-bottom: 12px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .misi-list ol li::before {
            content: counter(misi);
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            width: 34px;
            height: 34px;
            background: #0d6efd;
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/home/visimisi.blade.php ENDPATH**/ ?>