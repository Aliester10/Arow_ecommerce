<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white mb-3">
                <?php echo e($wisata->judul); ?>

            </h1>
            <nav>
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/wisata')); ?>">Wisata</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        <?php echo e($wisata->kategori->nama ?? 'Detail Wisata'); ?>

                    </li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container-xxl py-5">
        <div class="container">

            <div class="row g-5">

                <div class="col-lg-6">
                    <div id="wisataCarousel" class="carousel slide wisata-image shadow-sm" data-bs-ride="carousel">

                        <div class="carousel-inner">

                            <div class="carousel-item active">
                                <img src="<?php echo e(asset('storage/thumbnail/' . $wisata->thumbnail)); ?>" class="d-block w-100"
                                    alt="Thumbnail Wisata" style="height:420px; object-fit:cover;">
                            </div>

                            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item">
                                    <img src="<?php echo e(asset('storage/wisatafoto/' . $foto->foto)); ?>" class="d-block w-100"
                                        alt="Foto Wisata" style="height:420px; object-fit:cover;">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>


                        <button class="carousel-control-prev" type="button" data-bs-target="#wisataCarousel"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                        </button>

                        <button class="carousel-control-next" type="button" data-bs-target="#wisataCarousel"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon"></span>
                        </button>

                        <span class="badge bg-primary position-absolute m-3">
                            <?php echo e($wisata->kategori->nama ?? 'Wisata'); ?>

                        </span>
                    </div>
                </div>

                <div class="col-lg-6">
                    <h6 class="text-primary text-uppercase mb-2">
                        Visit Cianjur
                    </h6>

                    <h1 class="fw-bold mb-3">
                        <?php echo e($wisata->judul); ?>

                    </h1>

                    <p class="text-muted mb-2">
                        <i class="fa fa-map-marker-alt text-primary me-2"></i>
                        <?php echo e($wisata->alamat); ?>, <?php echo e($wisata->desa); ?>, <?php echo e($wisata->kecamatan); ?>

                    </p>

                    <p class="text-muted mb-3">
                        <i class="fa fa-clock text-primary me-2"></i>
                        <?php echo e($wisata->jambuka); ?> - <?php echo e($wisata->jamtutup); ?>

                    </p>

                    <p class="mb-4">
                        <?php echo $wisata->deskripsi; ?>

                    </p>

                    <div class="row g-3 mb-4">
                        <div class="col-6">
                            <div class="info-box">
                                <i class="fa fa-ticket-alt text-primary mb-2"></i>
                                <p class="fw-semibold mb-0">Harga Tiket</p>
                                <small class="text-muted">
                                    Rp <?php echo e(number_format($wisata->hargatiket, 0, ',', '.')); ?>

                                </small>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="info-box">
                                <i class="fa fa-tags text-primary mb-2"></i>
                                <p class="fw-semibold mb-0">Kategori</p>
                                <small class="text-muted">
                                    <?php echo e($wisata->kategori->nama); ?>

                                </small>
                            </div>
                        </div>
                    </div>

                    
                </div>

            </div>

            <div class="row mt-5">
                <div class="col-12">
                    <h4 class="fw-bold mb-3">
                        <i class="fa fa-map-marked-alt text-primary me-2"></i>Lokasi Wisata
                    </h4>
                    <div id="map"></div>
                </div>
            </div>

        </div>
    </div>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {

            var map = L.map('map').setView(
                [<?php echo e($wisata->lat); ?>, <?php echo e($wisata->lng); ?>],
                14
            );

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(map);

            L.marker([<?php echo e($wisata->lat); ?>, <?php echo e($wisata->lng); ?>])
                .addTo(map)
                .bindPopup(
                    `<b><?php echo e($wisata->judul); ?></b><br><?php echo e($wisata->alamat); ?>`
                );

            setTimeout(function() {
                map.invalidateSize();
            }, 500);

        });
    </script>

    <style>
        .wisata-image {
            border-radius: 16px;
            overflow: hidden;
        }

        .wisata-image img {
            height: 420px;
            object-fit: cover;
        }

        .info-box {
            border: 1px solid #eee;
            border-radius: 12px;
            padding: 16px;
            text-align: center;
            transition: .3s;
            background: #fff;
        }

        .info-box:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, .08);
        }

        #map {
            height: 400px;
            border-radius: 16px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/home/wisatadetail.blade.php ENDPATH**/ ?>