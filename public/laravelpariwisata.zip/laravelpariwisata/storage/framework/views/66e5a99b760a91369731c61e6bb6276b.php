<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-4">
                Struktur Organisasi
            </h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        Struktur Organisasi
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    
    <div class="container-xxl py-5">
        <div class="container">

            
            <div class="text-center mb-5">
                <h6 class="text-primary text-uppercase">
                    Visit Cianjur
                </h6>
                <h1 class="display-6 fw-bold">
                    Susunan Struktur Organisasi
                </h1>
                <p class="text-muted">
                    Tim pengelola dan pengembang Website Resmi Pariwisata Cianjur
                </p>
            </div>

            <div class="row g-4 justify-content-center">

                <?php $__currentLoopData = $strukturorganisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="card h-100 border-0 shadow-sm text-center struktur-card">

                            
                            <div class="position-relative overflow-hidden">
                                <img src="<?php echo e(asset('storage/strukturorganisasi/' . $item->foto)); ?>" class="w-100"
                                    style="height: 320px; object-fit: cover;" alt="<?php echo e($item->nama); ?>">

                                <div class="overlay"></div>
                            </div>

                            
                            <div class="card-body">
                                <h5 class="fw-bold mb-1">
                                    <?php echo e($item->nama); ?>

                                </h5>
                                <span class="badge bg-primary">
                                    <?php echo e($item->jabatan); ?>

                                </span>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($strukturorganisasi->isEmpty()): ?>
                    <div class="col-12 text-center">
                        <p class="text-muted">
                            Data struktur organisasi belum tersedia.
                        </p>
                    </div>
                <?php endif; ?>

            </div>

            
            <div class="d-flex justify-content-center mt-5">
                <?php echo e($strukturorganisasi->links('vendor.pagination.bootstrap-4')); ?>

            </div>

        </div>
    </div>

    
    <style>
        .struktur-card {
            transition: all 0.3s ease;
            border-radius: 12px;
            overflow: hidden;
        }

        .struktur-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }

        .struktur-card .overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.5), transparent);
        }

        .struktur-card img {
            transition: transform 0.4s ease;
        }

        .struktur-card:hover img {
            transform: scale(1.05);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/home/strukturorganisasi.blade.php ENDPATH**/ ?>