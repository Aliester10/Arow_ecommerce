<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn">
        <div class="container text-center py-5">
            <h1 class="display-5 text-white mb-3">
                <?php echo e($pengumuman->judul); ?>

            </h1>
            <nav>
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/pengumuman')); ?>">Pengumuman</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        Detail
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    
    <div class="container-xxl py-5">
        <div class="container">

            <div class="row g-5">

                
                <div class="col-lg-8">

                    <div class="card border-0 shadow-sm p-4 rounded-4">

                        
                        <img src="<?php echo e(asset('storage/pengumuman/' . $pengumuman->thumbnail)); ?>"
                            class="img-fluid rounded mb-4" alt="<?php echo e($pengumuman->judul); ?>">

                        
                        <div class="mb-3 text-muted small">
                            <i class="fa fa-calendar me-1"></i>
                            <?php echo e(date('d M Y', strtotime($pengumuman->created_at))); ?>

                        </div>

                        
                        <h2 class="fw-bold mb-4">
                            <?php echo e($pengumuman->judul); ?>

                        </h2>

                        
                        <div class="pengumuman-content">
                            <?php echo $pengumuman->deskripsi; ?>

                        </div>

                        
                        <div class="mt-4">
                            <a href="<?php echo e(asset('storage/pengumuman/' . $pengumuman->file)); ?>" target="_blank"
                                class="btn btn-primary px-4">
                                <i class="fa fa-download me-2"></i>
                                Download Lampiran
                            </a>
                        </div>

                    </div>

                </div>

                
                <div class="col-lg-4">

                    <div class="card border-0 shadow-sm rounded-4 p-4">

                        <h5 class="fw-bold mb-3">
                            Informasi Pengumuman
                        </h5>

                        <ul class="list-unstyled mb-0 small">
                            <li class="mb-2">
                                <i class="fa fa-calendar text-primary me-2"></i>
                                <?php echo e(date('d M Y', strtotime($pengumuman->created_at))); ?>

                            </li>
                            <li>
                                <i class="fa fa-file text-primary me-2"></i>
                                File Lampiran
                            </li>
                        </ul>

                    </div>
                    <?php if($pengumuman->file): ?>
                        <a href="<?php echo e(url('pengumuman')); ?>" class="btn btn-outline-primary w-100 mt-4">
                            <i class="fa fa-arrow-left me-2"></i>
                            Kembali ke Pengumuman
                        </a>
                    <?php endif; ?>

                </div>

            </div>

        </div>
    </div>

    
    <style>
        .pengumuman-content p {
            line-height: 1.8;
            margin-bottom: 1rem;
        }

        .pengumuman-content img {
            max-width: 100%;
            border-radius: 12px;
            margin: 15px 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/home/pengumumandetail.blade.php ENDPATH**/ ?>