<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">

            
            <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div class="flex-grow-1">
                    <h3 class="fw-bold mb-2 mb-md-0 text-center text-md-start">
                        Edit Kategori Wisata
                    </h3>
                </div>

                <div class="d-flex flex-wrap justify-content-center justify-content-md-end gap-2">
                    <a href="<?php echo e(url('panel/kategori')); ?>" class="btn btn-secondary">
                        <i class="fa fa-arrow-left me-1"></i> Kembali
                    </a>
                </div>
            </div>

            
            <div class="card mt-4">
                <div class="card-body">

                    <form action="<?php echo e(url('panel/kategoriupdate/' . $kategori->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Kategori</label>
                                <input type="text" name="nama" class="form-control"
                                    value="<?php echo e(old('nama', $kategori->nama)); ?>" required>
                            </div>

                        </div>

                        <div class="d-flex justify-content-end gap-2 mt-3">
                            <button type="reset" class="btn btn-warning">
                                <i class="fa fa-undo me-1"></i> Reset
                            </button>

                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\visicianjur-laravel\resources\views/panel/kategoriedit.blade.php ENDPATH**/ ?>