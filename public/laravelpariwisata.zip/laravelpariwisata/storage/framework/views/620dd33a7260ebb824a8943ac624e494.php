<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">

            
            <div class="page-header mb-4">
                <h3 class="fw-bold">Edit Hero</h3>
            </div>

            
            <div class="card">
                <div class="card-body">

                    <form action="<?php echo e(url('panel/heroupdate/' . $hero->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Judul</label>
                                <input type="text" name="judul" class="form-control" value="<?php echo e($hero->judul); ?>"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" rows="5" required><?php echo e($hero->deskripsi); ?></textarea>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Foto</label>
                                <input type="file" name="foto" class="form-control" accept="image/*">
                                <small class="text-muted">
                                    Kosongkan jika tidak ingin mengganti foto
                                </small>
                            </div>

                            <?php if($hero->foto): ?>
                                <div class="col-md-12 mb-3">
                                    <label class="fw-bold d-block">Foto Saat Ini</label>
                                    <img src="<?php echo e(asset('storage/hero/' . $hero->foto)); ?>" width="200"
                                        class="img-thumbnail">
                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                Update
                            </button>
                            <a href="<?php echo e(url('panel/hero')); ?>" class="btn btn-secondary">
                                Kembali
                            </a>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/panel/heroedit.blade.php ENDPATH**/ ?>