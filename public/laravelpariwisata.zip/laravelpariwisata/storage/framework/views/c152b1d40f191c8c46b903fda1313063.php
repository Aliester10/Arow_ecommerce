<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-5 text-white animated slideInDown mb-3">
                <?php echo e($artikel->judul); ?>

            </h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/artikel')); ?>">Artikel</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        Detail Artikel
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    
    <div class="container-xxl py-5">
        <div class="container">

            <div class="row g-5 justify-content-center">

                <div class="col-lg-9">

                    
                    <div class="artikel-image mb-4 shadow-sm">
                        <img src="<?php echo e(asset('storage/artikel/' . $artikel->thumbnail)); ?>" alt="<?php echo e($artikel->judul); ?>">
                    </div>

                    
                    <div class="d-flex flex-wrap align-items-center mb-3 artikel-meta">
                        <span class="badge bg-primary me-2">
                            <?php echo e($artikel->kategoriartikel->nama ?? 'Artikel'); ?>

                        </span>

                        <small class="text-muted me-3">
                            <i class="fa fa-calendar me-1"></i>
                            <?php echo e(date('d M Y', strtotime($artikel->created_at))); ?>

                        </small>

                        <small class="text-muted">
                            <i class="fa fa-user me-1"></i>
                            <?php echo e($artikel->publishedby->name ?? 'Admin'); ?>

                        </small>
                    </div>

                    
                    <h1 class="fw-bold mb-4">
                        <?php echo e($artikel->judul); ?>

                    </h1>

                    
                    <div class="artikel-content mb-5">
                        <?php echo $artikel->deskripsi; ?>

                    </div>

                    
                    <div class="d-flex justify-content-between align-items-center">
                        <a href="<?php echo e(url('/artikel')); ?>" class="btn btn-outline-primary">
                            <i class="fa fa-arrow-left me-2"></i>
                            Kembali ke Artikel
                        </a>

                        
                    </div>

                </div>

            </div>

        </div>
    </div>

    
    <style>
        .artikel-image {
            border-radius: 18px;
            overflow: hidden;
        }

        .artikel-image img {
            width: 100%;
            height: 420px;
            object-fit: cover;
            transition: transform .4s ease;
        }

        .artikel-image:hover img {
            transform: scale(1.05);
        }

        .artikel-meta {
            font-size: 0.9rem;
        }

        .artikel-content {
            line-height: 1.8;
            font-size: 1.05rem;
        }

        .artikel-content img {
            max-width: 100%;
            border-radius: 12px;
            margin: 15px 0;
        }

        .artikel-content p {
            margin-bottom: 1rem;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/home/artikeldetail.blade.php ENDPATH**/ ?>