<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">

            
            <div class="page-header d-flex justify-content-between align-items-center">
                <h3 class="fw-bold">Tambah Event</h3>
                <a href="<?php echo e(url('panel/event')); ?>" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            
            <div class="card mt-4">
                <div class="card-body">

                    <form action="<?php echo e(url('panel/eventsimpan')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Judul Event</label>
                                <input type="text" name="judul" class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Tanggal Mulai</label>
                                <input type="date" name="tanggalmulai" class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Tanggal Selesai</label>
                                <input type="date" name="tanggalselesai" class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Lokasi</label>
                                <input type="text" name="lokasi" class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" id="deskripsi" rows="3"></textarea>
                                <script>
                                    CKEDITOR.replace('deskripsi');
                                </script>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Poster</label>
                                <input type="file" name="poster" class="form-control" accept="image/*" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label>Status</label>
                                <select name="status" class="form-control" required>
                                    <option value="Aktif">Aktif</option>
                                    <option value="Non Aktif">Non Aktif</option>
                                </select>
                            </div>

                        </div>


                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save me-1"></i> Simpan
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/panel/eventtambah.blade.php ENDPATH**/ ?>