<?php $__env->startSection('content'); ?>
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white mb-4">Diary Perasaan</h1>
            <nav>
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">Diary</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5 align-items-center">

                <!-- GAMBAR ILUSTRASI -->
                <div class="col-lg-6">
                    <div class="position-relative overflow-hidden ps-5 pt-5 h-100" style="min-height: 400px;">
                        <img class="position-absolute w-100 h-100"
                            src="<?php echo e(asset('storage/website/' . $settingwebsite->logo)); ?>"
                            style="object-fit: cover; border-radius: 8px;">

                        <div class="position-absolute top-0 start-0 bg-white pe-3 pb-3"
                            style="width: 220px; height: 220px; border-radius:8px;">
                            <div class="d-flex flex-column justify-content-center text-center bg-primary h-100 p-3 rounded">
                                <h5 class="text-white mb-0"><?php echo e($settingwebsite->namaweb); ?></h5>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- DESKRIPSI -->
                <div class="col-lg-6">
                    <div>
                        <div class="border-start border-5 border-primary ps-4 mb-4">
                            <h2 class="fw-bold mb-0">Tentang <?php echo e($settingwebsite->namaweb); ?></h2>
                        </div>

                        <?php echo $settingwebsite->tentang; ?>


                        <div class="row g-4">
                            <div class="col-sm-6 d-flex align-items-center">
                                <i class="fa fa-map-marker-alt fa-2x text-primary me-3"></i>
                                <h6 class="mb-0">Destinasi Wisata</h6>
                            </div>

                            <div class="col-sm-6 d-flex align-items-center">
                                <i class="fa fa-landmark fa-2x text-primary me-3"></i>
                                <h6 class="mb-0">Budaya & Event</h6>
                            </div>

                            <div class="col-sm-6 d-flex align-items-center">
                                <i class="fa fa-hand-holding-usd fa-2x text-primary me-3"></i>
                                <h6 class="mb-0">Dukung Pelaku Wisata</h6>
                            </div>

                            <div class="col-sm-6 d-flex align-items-center">
                                <i class="fa fa-info-circle fa-2x text-primary me-3"></i>
                                <h6 class="mb-0">Transparansi Informasi</h6>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/home/tentang.blade.php ENDPATH**/ ?>