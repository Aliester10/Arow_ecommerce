<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo e($settingwebsite->namaweb); ?></title>
    <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
    <link rel="icon" href="<?php echo e(asset('storage/website/' . $settingwebsite->logo)); ?>" type="image/x-icon" />

    <!-- Fonts and icons -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
        WebFont.load({
            google: {
                families: ["Public Sans:300,400,500,600,700"]
            },
            custom: {
                families: [
                    "Font Awesome 5 Solid",
                    "Font Awesome 5 Regular",
                    "Font Awesome 5 Brands",
                    "simple-line-icons",
                ],
                urls: ["<?php echo e(asset('assets/panel')); ?>/assets/css/fonts.min.css"],
            },
            active: function() {
                sessionStorage.fonts = true;
            },
        });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/panel')); ?>/assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/panel')); ?>/assets/css/plugins.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/panel')); ?>/assets/css/kaiadmin.min.css" />

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css">

    <script src="<?php echo e(asset('assets/ckeditor/ckeditor.js')); ?>"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />



    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <style>
        /* ================= SIDEBAR ================= */
        .sidebar,
        .sidebar[data-background-color=light] {
            background-color: #1e3c72 !important;
            /* Biru */
            color: #f8f9fa !important;
            box-shadow: 4px 4px 12px rgba(0, 0, 0, .18);
        }

        /* Menu link */
        .sidebar .nav a {
            color: rgba(255, 255, 255, .92) !important;
            font-weight: 500;
            display: flex;
            align-items: center;
            padding: 10px 15px;
            border-radius: 10px;
            transition: all .25s ease;
        }

        /* Icon */
        .sidebar .nav i {
            color: rgba(255, 255, 255, .75) !important;
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Hover */
        .sidebar .nav a:hover {
            background: rgba(255, 255, 255, .15) !important;
            color: #ffffff !important;
        }

        .sidebar .nav a:hover i {
            color: #ffffff !important;
        }

        /* Active */
        .sidebar .nav-item.active>a {
            background: #ffffff !important;
            color: #2a9d8f !important;
            /* Hijau */
            font-weight: 600;
            box-shadow: inset 4px 0 0 #8d6e63;
            /* Coklat tanah */
        }

        .sidebar .nav-item.active>a i {
            color: #2a9d8f !important;
        }

        /* Section text */
        .sidebar .text-section {
            color: rgba(255, 255, 255, .65) !important;
            text-transform: uppercase;
            font-size: .75rem;
            letter-spacing: .6px;
            margin: 15px 0 5px;
        }

        /* Scrollbar */
        .sidebar-wrapper.scrollbar-inner::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-wrapper.scrollbar-inner::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, .35);
            border-radius: 3px;
        }

        /* ================= SIDEBAR TOP / LOGO ================= */
        .logo-header[data-background-color=light] {
            background-color: #8d6e63 !important;
            /* Coklat tanah */
            border-bottom: 1px solid rgba(255, 255, 255, .15);
        }

        .logo-header .logo,
        .logo-header .logo h4 {
            color: #ffffff !important;
            font-weight: 700;
        }

        /* Toggle buttons */
        .logo-header .btn-toggle,
        .logo-header .topbar-toggler.more {
            background: transparent !important;
            border: none;
        }

        .logo-header .btn-toggle i,
        .logo-header .topbar-toggler.more i {
            color: #ffffff !important;
            font-size: 18px;
        }

        .logo-header .btn-toggle:hover i,
        .logo-header .topbar-toggler.more:hover i {
            color: #f1e4dd !important;
        }

        /* ================= NAVBAR / HEADER ================= */
        .main-header {
            background-color: #2a9d8f !important;
            /* Hijau */
            min-height: 60px;
            width: calc(100% - 250px);
            position: fixed;
            z-index: 1001;
            box-shadow: 0 4px 10px rgba(0, 0, 0, .18);
        }


        /* ================= BUTTON PRIMARY ================= */
        /* .btn-primary {
            background-color: #2a9d8f !important;
            border-color: #2a9d8f !important;
        }

        .btn-primary:hover {
            background-color: #21867a !important;
            border-color: #21867a !important;
        }

        .btn-primary:focus,
        .btn-primary:focus-visible {
            background-color: #21867a !important;
            border-color: #21867a !important;
            box-shadow: 0 0 0 .25rem rgba(42, 157, 143, .45) !important;
        }

        .btn-primary:active,
        .btn-primary.active {
            background-color: #1b6f65 !important;
            border-color: #1b6f65 !important;
        }

        .btn-primary:disabled {
            background-color: #9ad2ca !important;
            border-color: #9ad2ca !important;
        } */
    </style>

</head>

<body>
    <div class="wrapper">
        <!-- Sidebar -->

        <div class="sidebar" data-background-color="light">
            <div class="sidebar-logo">
                <!-- Logo Header -->
                <div class="logo-header" data-background-color="light">
                    
                    <a href="<?php echo e(url('panel')); ?>" class="logo d-flex">
                        <h4 class="mb-0 text-black fw-bold mt-1 ms-4"><?php echo e($settingwebsite->namaweb); ?></h4>
                    </a>

                    <div class="nav-toggle">
                        <button class="btn btn-toggle toggle-sidebar">
                            <i class="gg-menu-right"></i>
                        </button>
                        <button class="btn btn-toggle sidenav-toggler">
                            <i class="gg-menu-left"></i>
                        </button>
                    </div>

                    <button class="topbar-toggler more">
                        <i class="gg-more-vertical-alt"></i>
                    </button>
                </div>

                <!-- End Logo Header -->
            </div>
            <div class="sidebar-wrapper scrollbar scrollbar-inner">
                <div class="sidebar-content">
                    <!-- User Profile -->
                    <div class="sidebar-user px-3 py-3 mb-2">
                        <div class="d-flex align-items-center">
                            <!-- Avatar -->
                            <div class="avatar avatar-lg rounded-circle bg-white text-primary
                    d-flex align-items-center justify-content-center fw-bold me-3"
                                style="width:48px;height:48px;">
                                <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                            </div>

                            <!-- User Info -->
                            <div class="user-info">
                                <div class="fw-semibold text-white">
                                    <?php echo e(auth()->user()->name); ?>

                                </div>
                                <small class="text-white-50">
                                    <?php echo e(auth()->user()->role); ?>

                                </small>
                            </div>
                        </div>
                    </div>
                    <!-- End User Profile -->

                    <hr class="my-2" style="border-color: white">

                    <ul class="nav nav-secondary">

                        
                        <li class="nav-item <?php echo e(Request::is('panel') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('panel')); ?>">
                                <i class="fas fa-home"></i>
                                <p>Dashboard</p>
                            </a>
                        </li>

                        <?php if(auth()->user()->role == 'Super Admin'): ?>
                            <li class="nav-section">
                                <h4 class="text-section">Master Data</h4>
                            </li>

                            <li
                                class="nav-item <?php echo e(Request::is('panel/kategori') || Request::is('panel/kategoriedit/*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/kategori')); ?>">
                                    <i class="fas fa-tags"></i>
                                    <p>Kategori Wisata</p>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/wisata*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/wisata')); ?>">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <p>Destinasi Wisata</p>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/event*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/event')); ?>">
                                    <i class="fas fa-calendar-alt"></i>
                                    <p>Event/Budaya</p>
                                </a>
                            </li>

                            <li class="nav-section">
                                <h4 class="text-section">Artikel</h4>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/kategoriartikel*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/kategoriartikel')); ?>">
                                    <i class="fas fa-tags"></i>
                                    <p>Kategori Artikel</p>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/artikel*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/artikel')); ?>">
                                    <i class="fas fa-newspaper"></i>
                                    <p>Berita/Artikel</p>
                                </a>
                            </li>

                            <li class="nav-section">
                                <h4 class="text-section">Galeri</h4>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/kategorigaleri*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/kategorigaleri')); ?>">
                                    <i class="fas fa-tags"></i>
                                    <p>Kategori Galeri</p>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/galeri*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/galeri')); ?>">
                                    <i class="fas fa-image"></i>
                                    <p>Galeri</p>
                                </a>
                            </li>

                            <li class="nav-section">
                                <h4 class="text-section">Informasi Publik</h4>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/pengumuman*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/pengumuman')); ?>">
                                    <i class="fas fa-bullhorn"></i>
                                    <p>Pengumuman</p>
                                </a>
                            </li>

                            <li class="nav-section">
                                <h4 class="text-section">Website</h4>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/strukturorganisasi*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/strukturorganisasi')); ?>">
                                    <i class="fas fa-users"></i>
                                    <p>Struktur Organisasi</p>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/hero*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/hero')); ?>">
                                    <i class="fas fa-layer-group"></i>
                                    <p>Hero Banner</p>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/website*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/website')); ?>">
                                    <i class="fas fa-cogs"></i>
                                    <p>Pengaturan Website</p>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->role == 'Admin'): ?>
                            <li class="nav-section">
                                <h4 class="text-section">Master Data</h4>
                            </li>

                            <li
                                class="nav-item <?php echo e(Request::is('panel/kategori') || Request::is('panel/kategoriedit/*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/kategori')); ?>">
                                    <i class="fas fa-tags"></i>
                                    <p>Kategori Wisata</p>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/wisata*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/wisata')); ?>">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <p>Destinasi Wisata</p>
                                </a>
                            </li>

                            <li class="nav-section">
                                <h4 class="text-section">Artikel</h4>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/kategoriartikel*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/kategoriartikel')); ?>">
                                    <i class="fas fa-tags"></i>
                                    <p>Kategori Artikel</p>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(Request::is('panel/artikel*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('panel/artikel')); ?>">
                                    <i class="fas fa-newspaper"></i>
                                    <p>Berita/Artikel</p>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <!-- End Sidebar -->

        <div class="main-panel">
            <div class="main-header">
                <div class="main-header-logo">
                    <!-- Logo Header -->
                    <div class="logo-header" data-background-color="light">
                        <a href="<?php echo e(url('panel')); ?>" class="logo">
                            
                            <h4 class="text-black"><?php echo e($settingwebsite->namaweb); ?></h4>
                        </a>
                        <div class="nav-toggle">
                            <button class="btn btn-toggle toggle-sidebar">
                                <i class="gg-menu-right"></i>
                            </button>
                            <button class="btn btn-toggle sidenav-toggler">
                                <i class="gg-menu-left"></i>
                            </button>
                        </div>
                        <button class="topbar-toggler more">
                            <i class="gg-more-vertical-alt"></i>
                        </button>
                    </div>
                    <!-- End Logo Header -->
                </div>
                <!-- Navbar Header -->
                <nav class="navbar navbar-header navbar-header-transparent navbar-expand-lg border-bottom">
                    <div class="container-fluid">

                        <ul class="navbar-nav topbar-nav ms-md-auto align-items-center">

                            <li class="nav-item topbar-user dropdown hidden-caret">
                                <a class="dropdown-toggle profile-pic" data-bs-toggle="dropdown" href="#"
                                    aria-expanded="false">
                                    <div class="avatar-sm">
                                        <img src="<?php echo e(asset('assets/foto/avatar.png')); ?>" alt="..."
                                            class="avatar-img rounded-circle" />
                                    </div>
                                    <span class="profile-username">
                                        <span class="op-7 text-white">Hi,</span>
                                        <span class="fw-bold text-white"><?php echo e(auth()->user()->name); ?></span>
                                    </span>
                                </a>
                                <ul class="dropdown-menu dropdown-user animated fadeIn">
                                    <div class="dropdown-user-scroll scrollbar-outer">
                                        <li>
                                            <div class="user-box">
                                                <div class="avatar-lg">
                                                    <img src="<?php echo e(asset('assets/foto/avatar.png')); ?>"
                                                        alt="image profile" class="avatar-img rounded" />
                                                </div>
                                                <div class="u-text">
                                                    <h4><?php echo e(auth()->user()->name); ?></h4>
                                                    <p class="text-muted"><?php echo e(auth()->user()->email); ?></p>
                                                    <!--<a href="<?php echo e(url('panel/profile')); ?>"-->
                                                    <!--    class="btn btn-xs btn-secondary btn-sm">View Profile</a>-->
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <!--<div class="dropdown-divider"></div>-->
                                            <!--<a class="dropdown-item" href="<?php echo e(url('panel/profile')); ?>">My Profile</a>-->
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="<?php echo e(url('logout')); ?>"
                                                onclick="return confirm('Yakin ingin logout?')">Logout</a>
                                        </li>
                                    </div>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Navbar -->
            </div>

            <?php echo $__env->yieldContent('content'); ?>

            <footer class="footer">
                <div class="container-fluid d-flex justify-content-between">
                    <div class="copyright">
                        <?php echo e(date('Y')); ?>, made with <i class="fa fa-heart heart text-danger"></i> by
                        <a href="<?php echo e(url('/')); ?>"><?php echo e($settingwebsite->namaweb); ?></a>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/core/popper.min.js"></script>
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/core/bootstrap.min.js"></script>

    <!-- jQuery Scrollbar -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

    <!-- Chart JS -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/plugin/chart.js/chart.min.js"></script>

    <!-- jQuery Sparkline -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

    <!-- Chart Circle -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/plugin/chart-circle/circles.min.js"></script>

    <!-- Datatables -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/plugin/datatables/datatables.min.js"></script>

    <!-- Bootstrap Notify -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

    <!-- jQuery Vector Maps -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/plugin/jsvectormap/jsvectormap.min.js"></script>
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/plugin/jsvectormap/world.js"></script>

    <!-- Sweet Alert -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/plugin/sweetalert/sweetalert.min.js"></script>

    <!-- Kaiadmin JS -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/kaiadmin.min.js"></script>


    <!-- Kaiadmin JS -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/kaiadmin.min.js"></script>
    <!-- Kaiadmin DEMO methods, don't include it in your project! -->
    <script src="<?php echo e(asset('assets/panel')); ?>/assets/js/setting-demo2.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/responsive.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#datatable').DataTable({
                responsive: true,
                language: {
                    url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json"
                }
            });
        });
    </script>


    <?php if(session('success')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: "<?php echo e(session('success')); ?>"
            });
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "error",
                title: "<?php echo e(session('error')); ?>"
            });
        </script>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <script>
            let errorMessages = `
            <ul style="text-align:left;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        `;
            Swal.fire({
                icon: 'warning',
                title: 'Validasi Gagal',
                html: errorMessages,
                confirmButtonColor: '#f0ad4e',
                confirmButtonText: 'Perbaiki'
            });
        </script>
    <?php endif; ?>


    <script>
        $("#lineChart").sparkline([102, 109, 120, 99, 110, 105, 115], {
            type: "line",
            height: "70",
            width: "100%",
            lineWidth: "2",
            lineColor: "#177dff",
            fillColor: "rgba(23, 125, 255, 0.14)",
        });

        $("#lineChart2").sparkline([99, 125, 122, 105, 110, 124, 115], {
            type: "line",
            height: "70",
            width: "100%",
            lineWidth: "2",
            lineColor: "#f3545d",
            fillColor: "rgba(243, 84, 93, .14)",
        });

        $("#lineChart3").sparkline([105, 103, 123, 100, 95, 105, 115], {
            type: "line",
            height: "70",
            width: "100%",
            lineWidth: "2",
            lineColor: "#ffa534",
            fillColor: "rgba(255, 165, 52, .14)",
        });
    </script>

    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH E:\Project Laravel\visicianjur-laravel\resources\views/layouts/panel.blade.php ENDPATH**/ ?>