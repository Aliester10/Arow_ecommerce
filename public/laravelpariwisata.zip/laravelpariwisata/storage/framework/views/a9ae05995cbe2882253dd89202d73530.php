<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">

            
            <div class="page-header d-flex justify-content-between align-items-center">
                <h3 class="fw-bold">Edit Wisata</h3>
                <a href="<?php echo e(url('panel/wisata')); ?>" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            <div class="card mt-4">
                <div class="card-body">

                    <form action="<?php echo e(url('panel/wisataupdate/' . $wisata->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Judul Wisata</label>
                                <input type="text" name="judul" value="<?php echo e($wisata->judul); ?>" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Kategori</label>
                                <select name="kategori_id" class="form-control" required>
                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k->id); ?>"
                                            <?php echo e($wisata->kategori_id == $k->id ? 'selected' : ''); ?>>
                                            <?php echo e($k->nama); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Jam Buka</label>
                                <input type="time" name="jambuka" value="<?php echo e($wisata->jambuka); ?>" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Jam Tutup</label>
                                <input type="time" name="jamtutup" value="<?php echo e($wisata->jamtutup); ?>" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Alamat</label>
                                <input type="text" name="alamat" value="<?php echo e($wisata->alamat); ?>" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Desa</label>
                                <input type="text" name="desa" value="<?php echo e($wisata->desa); ?>" class="form-control"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Kecamatan</label>
                                <input type="text" name="kecamatan" value="<?php echo e($wisata->kecamatan); ?>"
                                    class="form-control" required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" id="deskripsi" rows="3"><?php echo e($wisata->deskripsi); ?></textarea>
                                <script>
                                    CKEDITOR.replace('deskripsi');
                                </script>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Harga Tiket</label>
                                <input type="number" name="hargatiket" value="<?php echo e($wisata->hargatiket); ?>"
                                    class="form-control" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Koordinat</label>
                                <div class="d-flex gap-2">
                                    <input type="text" name="lat" value="<?php echo e($wisata->lat); ?>" class="form-control"
                                        readonly>
                                    <input type="text" name="lng" value="<?php echo e($wisata->lng); ?>" class="form-control"
                                        readonly>
                                </div>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Lokasi Wisata</label>
                                <div id="map" style="height: 400px; border-radius: 12px;"></div>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Thumbnail</label>
                                <input type="file" name="thumbnail" class="form-control">
                                <?php if($wisata->thumbnail): ?>
                                    <img src="<?php echo e(asset('storage/thumbnail/' . $wisata->thumbnail)); ?>"
                                        class="img-thumbnail mt-2" width="150">
                                <?php endif; ?>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label>Status</label>
                                <select name="status" class="form-control" required>
                                    <option value="Aktif" <?php echo e($wisata->status == 'Aktif' ? 'selected' : ''); ?>>Aktif
                                    </option>
                                    <option value="Non Aktif" <?php echo e($wisata->status == 'Non Aktif' ? 'selected' : ''); ?>>
                                        Non
                                        Aktif</option>
                                </select>
                            </div>

                        </div>

                        <div class="text-end">
                            <button class="btn btn-primary">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                        </div>

                    </form>

                    <hr>

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold mb-0">Foto Wisata</h5>
                        <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalTambahFoto">
                            <i class="fa fa-plus me-1"></i> Tambah Foto
                        </button>
                    </div>

                    <table class="table table-bordered align-middle">
                        <thead class="table-light text-center">
                            <tr>
                                <th>Foto</th>
                                <th width="100">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $wisata->wisatafoto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo e(asset('storage/wisatafoto/' . $foto->foto)); ?>" width="120"
                                            class="img-thumbnail">
                                    </td>
                                    <td class="text-center">
                                        <form action="<?php echo e(url('panel/wisatafotohapus/' . $foto->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-danger"
                                                onclick="return confirm('Hapus foto ini?')">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="modal fade" id="modalTambahFoto" tabindex="-1">
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            <div class="modal-content">

                                <div class="modal-header bg-success text-white">
                                    <h5 class="modal-title">Tambah Foto Wisata</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>

                                <form action="<?php echo e(url('panel/wisatafotosimpan/' . $wisata->id)); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label class="fw-bold">Pilih Foto</label>
                                            <input type="file" name="wisatafoto[]" class="form-control"
                                                accept="image/*" multiple required>
                                            <small class="text-muted">
                                                Bisa pilih lebih dari satu foto
                                            </small>
                                        </div>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                            Batal
                                        </button>
                                        <button type="submit" class="btn btn-success">
                                            <i class="fa fa-upload me-1"></i> Upload
                                        </button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>


                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css">
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script>
        let map, marker;

        document.addEventListener('DOMContentLoaded', function() {

            const lat = <?php echo e($wisata->lat); ?>;
            const lng = <?php echo e($wisata->lng); ?>;

            map = L.map('map').setView([lat, lng], 14);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap'
            }).addTo(map);

            marker = L.marker([lat, lng]).addTo(map);

            map.on('click', function(e) {
                const newLat = e.latlng.lat.toFixed(6);
                const newLng = e.latlng.lng.toFixed(6);

                document.querySelector('input[name="lat"]').value = newLat;
                document.querySelector('input[name="lng"]').value = newLng;

                marker.setLatLng(e.latlng);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/panel/wisataedit.blade.php ENDPATH**/ ?>