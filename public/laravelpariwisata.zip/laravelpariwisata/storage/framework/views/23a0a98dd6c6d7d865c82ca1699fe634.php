<?php $__env->startSection('content'); ?>
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white mb-4">
                Galeri
            </h1>
            <nav>
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        Galeri
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container-xxl py-5">
        <div class="container">

            <div class="text-center mb-5">
                <h6 class="text-primary text-uppercase">
                    Dokumentasi
                </h6>
                <h1 class="fw-bold display-6">
                    Galeri Foto & Video
                </h1>
                <p class="text-muted">
                    Dokumentasi kegiatan, wisata, dan event
                </p>
            </div>

            <div class="row g-4">

                <?php $__empty_1 = true; $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6">

                        <div class="galeri-card shadow-sm"
                            onclick="openGaleriModal('<?php echo e($item->tipe); ?>', '<?php echo e(asset('storage/galeri/' . $item->file)); ?>', '<?php echo e($item->judul); ?>')">

                            <?php if($item->tipe === 'Gambar'): ?>
                                <img src="<?php echo e(asset('storage/galeri/' . $item->file)); ?>" alt="<?php echo e($item->judul); ?>"
                                    class="galeri-img">
                            <?php elseif($item->tipe === 'Video'): ?>
                                <div class="galeri-video">
                                    <video muted>
                                        <source src="<?php echo e(asset('storage/galeri/' . $item->file)); ?>" type="video/mp4">
                                    </video>
                                </div>
                            <?php endif; ?>

                            <div class="galeri-overlay">
                                <h5 class="text-white"><?php echo e($item->judul); ?></h5>
                                <span class="badge bg-primary"><?php echo e($item->tipe); ?></span>
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center">
                        <p class="text-muted">
                            Belum ada galeri ditambahkan.
                        </p>
                    </div>
                <?php endif; ?>

            </div>

            <div class="d-flex justify-content-center mt-5">
                <?php echo e($galeri->links('vendor.pagination.bootstrap-4')); ?>

            </div>

        </div>
    </div>

    <div class="modal fade" id="galeriModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-xl">
            <div class="modal-content bg-dark border-0">

                <div class="modal-header border-0">
                    <h5 class="modal-title text-white" id="galeriTitle"></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body text-center" id="galeriContent">
                </div>

            </div>
        </div>
    </div>
    <script>
        function openGaleriModal(tipe, file, judul) {
            const content = document.getElementById('galeriContent');
            const title = document.getElementById('galeriTitle');

            title.innerText = judul;
            content.innerHTML = '';

            if (tipe === 'Gambar') {
                content.innerHTML = `
                <img src="${file}" class="img-fluid rounded" style="max-height: 80vh;">
            `;
            } else if (tipe === 'Video') {
                content.innerHTML = `
                    <video controls preload="auto" class="w-100 rounded" style="max-height: 80vh;">
                        <source src="${file}" type="video/mp4">
                        Browser tidak mendukung video.
                    </video>
                `;
            }

            const modal = new bootstrap.Modal(document.getElementById('galeriModal'));
            modal.show();
        }

        document.getElementById('galeriModal').addEventListener('hidden.bs.modal', function() {
            document.getElementById('galeriContent').innerHTML = '';
        });
    </script>


    <style>
        .galeri-card {
            position: relative;
            border-radius: 16px;
            overflow: hidden;
            height: 260px;
            background: #000;
            transition: all .3s ease;
        }

        .galeri-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, .2);
        }

        .galeri-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform .4s ease;
        }

        .galeri-card:hover .galeri-img {
            transform: scale(1.1);
        }

        .galeri-video video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .galeri-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, .8), transparent);
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 15px;
        }

        .galeri-overlay h5 {
            margin: 0 0 5px;
            font-weight: 600;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/home/galeri.blade.php ENDPATH**/ ?>