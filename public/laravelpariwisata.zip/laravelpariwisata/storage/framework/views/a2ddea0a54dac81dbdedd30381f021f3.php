<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-4">
                Wisata <?php echo e($kategori->nama ?? ''); ?>

            </h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a class="text-white" href="<?php echo e(url('/wisata')); ?>">Wisata</a>
                    </li>
                    <li class="breadcrumb-item text-primary active">
                        <?php echo e($kategori->nama ?? 'Kategori'); ?>

                    </li>
                </ol>
            </nav>
        </div>
    </div>

    
    <div class="container-xxl py-5">
        <div class="container">

            
            <div class="text-center mb-5">
                <h6 class="text-primary text-uppercase">
                    Visit Cianjur
                </h6>
                <h1 class="display-6 fw-bold">
                    Destinasi Wisata <?php echo e($kategori->nama ?? ''); ?>

                </h1>
                <p class="text-muted">
                    Jelajahi destinasi wisata terbaik di Kabupaten Cianjur
                </p>
            </div>

            <div class="row g-4">

                <?php $__currentLoopData = $wisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="card wisata-card h-100 border-0 shadow-sm">

                            <div class="position-relative overflow-hidden">
                                <img src="<?php echo e(asset('storage/thumbnail/' . $item->thumbnail)); ?>" class="w-100"
                                    style="height: 230px; object-fit: cover;" alt="<?php echo e($item->judul); ?>">

                                <span class="badge bg-primary position-absolute top-0 start-0 m-3">
                                    <?php echo e($item->kategori->nama ?? 'Wisata'); ?>

                                </span>
                            </div>

                            <div class="card-body d-flex flex-column">
                                <h5 class="fw-bold mb-2">
                                    <?php echo e($item->judul); ?>

                                </h5>

                                <p class="text-muted small mb-3">
                                    <i class="fa fa-map-marker-alt text-primary me-1"></i>
                                    <?php echo e($item->desa); ?>, <?php echo e($item->kecamatan); ?>

                                </p>

                                <p class="text-muted mb-4">
                                    <?php echo e(Str::limit(strip_tags($item->deskripsi), 100)); ?>

                                </p>

                                <a href="<?php echo e(url('wisatadetail/' . $item->id)); ?>" class="btn btn-outline-primary mt-auto">
                                    Lihat Detail
                                </a>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($wisata->isEmpty()): ?>
                    <div class="col-12 text-center">
                        <p class="text-muted">
                            Belum ada wisata pada kategori ini.
                        </p>
                    </div>
                <?php endif; ?>

            </div>

            <div class="d-flex justify-content-center mt-5">
                <?php echo e($wisata->links('vendor.pagination.bootstrap-4')); ?>

            </div>

        </div>
    </div>

    <style>
        .wisata-card {
            border-radius: 14px;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .wisata-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }

        .wisata-card img {
            transition: transform 0.4s ease;
        }

        .wisata-card:hover img {
            transform: scale(1.06);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/home/kategori.blade.php ENDPATH**/ ?>