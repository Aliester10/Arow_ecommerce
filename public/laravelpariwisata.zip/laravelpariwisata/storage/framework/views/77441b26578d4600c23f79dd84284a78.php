<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">

            
            <div class="page-header d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold">Edit Website</h3>
                <a href="<?php echo e(url('panel/website')); ?>" class="btn btn-secondary">
                    <i class="fa fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            
            <div class="card">
                <div class="card-body">

                    <form action="<?php echo e(url('panel/websiteupdate')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Nama Website</label>
                                <input type="text" name="namaweb" class="form-control" value="<?php echo e($website->namaweb); ?>"
                                    required>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Tentang</label>
                                <textarea name="tentang" class="form-control" rows="4" id="tentang" required><?php echo e($website->tentang); ?></textarea>
                                <script>
                                    CKEDITOR.replace('tentang');
                                </script>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Visi</label>
                                <textarea name="visi" class="form-control" rows="3" required><?php echo e($website->visi); ?></textarea>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Misi</label>
                                <textarea name="misi" class="form-control" rows="3" id="misi" required><?php echo e($website->misi); ?></textarea>
                                <script>
                                    CKEDITOR.replace('misi');
                                </script>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Logo</label>
                                <input type="file" name="logo" class="form-control" accept="image/*">
                                <small class="text-muted">Kosongkan jika tidak ingin mengganti logo</small>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Email</label>
                                <input type="email" name="email" class="form-control" value="<?php echo e($website->email); ?>"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">No HP</label>
                                <input type="text" name="nohp" class="form-control" value="<?php echo e($website->nohp); ?>"
                                    required>
                            </div>

                            <?php if($website->logo): ?>
                                <div class="col-md-12 mb-3">
                                    <label class="fw-bold d-block">Logo Saat Ini</label>
                                    <img src="<?php echo e(asset('storage/website/' . $website->logo)); ?>" width="120"
                                        class="img-thumbnail">
                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-warning">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project Laravel\laravelpariwisata\resources\views/panel/website.blade.php ENDPATH**/ ?>