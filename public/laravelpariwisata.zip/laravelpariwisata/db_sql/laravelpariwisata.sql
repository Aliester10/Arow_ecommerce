-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table laravelpariwisata.artikel
CREATE TABLE IF NOT EXISTS `artikel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kategoriartikel_id` bigint NOT NULL DEFAULT '0',
  `published_by` bigint NOT NULL DEFAULT '0',
  `judul` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_general_ci NOT NULL,
  `thumbnail` text COLLATE utf8mb4_general_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.artikel: ~1 rows (approximately)
DELETE FROM `artikel`;
INSERT INTO `artikel` (`id`, `kategoriartikel_id`, `published_by`, `judul`, `deskripsi`, `thumbnail`, `status`, `created_at`, `updated_at`) VALUES
	(1, 2, 1, 'Modul Sosialisasi Keselamatan Berlalulintas', '<p>asdasdasasdafgrgherth</p><p>twefwefwewfwfef</p>', '8eAyBOdfozoADRk70e8IPGg33T9gBGBePE5GKE9E.jpg', 'Aktif', '2026-01-29 05:56:28', '2026-01-29 05:58:49');

-- Dumping structure for table laravelpariwisata.cache
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravelpariwisata.cache: ~0 rows (approximately)
DELETE FROM `cache`;

-- Dumping structure for table laravelpariwisata.cache_locks
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravelpariwisata.cache_locks: ~0 rows (approximately)
DELETE FROM `cache_locks`;

-- Dumping structure for table laravelpariwisata.event
CREATE TABLE IF NOT EXISTS `event` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_general_ci NOT NULL,
  `tanggalmulai` date NOT NULL,
  `tanggalselesai` date NOT NULL,
  `lokasi` text COLLATE utf8mb4_general_ci NOT NULL,
  `poster` text COLLATE utf8mb4_general_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.event: ~1 rows (approximately)
DELETE FROM `event`;
INSERT INTO `event` (`id`, `judul`, `deskripsi`, `tanggalmulai`, `tanggalselesai`, `lokasi`, `poster`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'CFD', '<p>sadaddadadad</p><p>adadadadad</p>', '2026-01-31', '2026-02-01', 'Kabupaten Bogor, Desa Sentul Eco', 'c42mNKhUL42KnQLRZg7OfH6eSJIwMZx4x2g8c8QU.webp', 'Aktif', '2026-01-29 05:33:36', '2026-01-29 05:36:14');

-- Dumping structure for table laravelpariwisata.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravelpariwisata.failed_jobs: ~0 rows (approximately)
DELETE FROM `failed_jobs`;

-- Dumping structure for table laravelpariwisata.galeri
CREATE TABLE IF NOT EXISTS `galeri` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kategorigaleri_id` bigint NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tipe` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `file` text COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.galeri: ~2 rows (approximately)
DELETE FROM `galeri`;
INSERT INTO `galeri` (`id`, `kategorigaleri_id`, `judul`, `tipe`, `file`, `created_at`, `updated_at`) VALUES
	(2, 2, 'asdasdasdsads', 'Gambar', 'aP38juQB5zE1tsJdqFa2OsX2ZwKeUGWWN0OvPSA3.jpg', '2026-01-30 01:55:40', '2026-01-30 01:55:40'),
	(3, 2, 'Modul Sosialisasi Keselamatan Berlalulintas', 'Video', 'WBth0XU8ShK4YKLJUaQE98J2KgJ6zXyrtsFNsmCO.mp4', '2026-01-30 01:56:07', '2026-01-30 01:56:07');

-- Dumping structure for table laravelpariwisata.hero
CREATE TABLE IF NOT EXISTS `hero` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_general_ci NOT NULL,
  `foto` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.hero: ~2 rows (approximately)
DELETE FROM `hero`;
INSERT INTO `hero` (`id`, `judul`, `deskripsi`, `foto`) VALUES
	(1, 'Selamat datang di Visit Cianjur', 'Ini adalah website untuk Media informasi resmi pariwisata Cianjur', '0oI7hmu3VWlY7jCdJQp3RPRbFwRGnkiE39eM2q7n.webp'),
	(2, 'Pengertian Lalu Lintas dan Pelanggaran Lalu Lintas', 'asdasdasdsadsadadsad', 'u2J0vein0szA6EiITQ86MCjJEXxGGO2uNcCoTBPx.jpg');

-- Dumping structure for table laravelpariwisata.jobs
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravelpariwisata.jobs: ~0 rows (approximately)
DELETE FROM `jobs`;

-- Dumping structure for table laravelpariwisata.job_batches
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravelpariwisata.job_batches: ~0 rows (approximately)
DELETE FROM `job_batches`;

-- Dumping structure for table laravelpariwisata.kategori
CREATE TABLE IF NOT EXISTS `kategori` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.kategori: ~0 rows (approximately)
DELETE FROM `kategori`;
INSERT INTO `kategori` (`id`, `nama`) VALUES
	(2, 'Kategori 1'),
	(3, 'Kategori 2');

-- Dumping structure for table laravelpariwisata.kategoriartikel
CREATE TABLE IF NOT EXISTS `kategoriartikel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.kategoriartikel: ~2 rows (approximately)
DELETE FROM `kategoriartikel`;
INSERT INTO `kategoriartikel` (`id`, `nama`) VALUES
	(1, 'Politik'),
	(2, 'Sosial');

-- Dumping structure for table laravelpariwisata.kategorigaleri
CREATE TABLE IF NOT EXISTS `kategorigaleri` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.kategorigaleri: ~0 rows (approximately)
DELETE FROM `kategorigaleri`;
INSERT INTO `kategorigaleri` (`id`, `nama`) VALUES
	(2, 'Kategori 1');

-- Dumping structure for table laravelpariwisata.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravelpariwisata.migrations: ~0 rows (approximately)
DELETE FROM `migrations`;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '0001_01_01_000000_create_users_table', 1),
	(2, '0001_01_01_000001_create_cache_table', 1),
	(3, '0001_01_01_000002_create_jobs_table', 1);

-- Dumping structure for table laravelpariwisata.password_reset_tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravelpariwisata.password_reset_tokens: ~0 rows (approximately)
DELETE FROM `password_reset_tokens`;

-- Dumping structure for table laravelpariwisata.pengumuman
CREATE TABLE IF NOT EXISTS `pengumuman` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_general_ci NOT NULL,
  `file` text COLLATE utf8mb4_general_ci NOT NULL,
  `thumbnail` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.pengumuman: ~0 rows (approximately)
DELETE FROM `pengumuman`;
INSERT INTO `pengumuman` (`id`, `judul`, `deskripsi`, `file`, `thumbnail`, `created_at`, `updated_at`) VALUES
	(1, 'Pengumuman 1', '<p>sadasdasddsda</p><p>asdsadsdasdad</p>', 'AZGZGBHQlSanDrdRHq7KZ6OqMAMYzP7g9jwGazvX.docx', 'xy8BT6khsmGIuU6RpfVVsEcxxxtL5XDBRGSKmrwu.png', '2026-01-29 11:50:15', '2026-01-29 11:53:35');

-- Dumping structure for table laravelpariwisata.sessions
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravelpariwisata.sessions: ~3 rows (approximately)
DELETE FROM `sessions`;
INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
	('XuYlT8N9c06bwACW79YtzSNioRYieHYsBxysf9fP', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTER0UXdkQ2VZSDk5dzBreld2M1ZiUmw3a0o3T0ZXdnVCdzNmWklSciI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMCI7czo1OiJyb3V0ZSI7Tjt9fQ==', 1769856374);

-- Dumping structure for table laravelpariwisata.strukturorganisasi
CREATE TABLE IF NOT EXISTS `strukturorganisasi` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `jabatan` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `foto` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.strukturorganisasi: ~0 rows (approximately)
DELETE FROM `strukturorganisasi`;
INSERT INTO `strukturorganisasi` (`id`, `nama`, `jabatan`, `foto`) VALUES
	(1, 'Fahrul Adib', 'Kepala Desa', 'U0sUxOA7Kxm9nKx25SqPwXh7pDnH6BCufd9m8xnM.jpg');

-- Dumping structure for table laravelpariwisata.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravelpariwisata.users: ~0 rows (approximately)
DELETE FROM `users`;
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'Super Admin', 'superadmin@gmail.com', NULL, '$2y$12$RKaMmXc6A7YLA.ankg6sNeQPxpjoHs/wxfKw2WM/qve81sihhiOjK', 'Super Admin', NULL, NULL, '2026-01-31 03:46:05'),
	(2, 'Administrator', 'admin@gmail.com', NULL, '$2y$12$RKaMmXc6A7YLA.ankg6sNeQPxpjoHs/wxfKw2WM/qve81sihhiOjK', 'Admin', NULL, NULL, '2026-01-29 20:20:52');

-- Dumping structure for table laravelpariwisata.website
CREATE TABLE IF NOT EXISTS `website` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `namaweb` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `tentang` text COLLATE utf8mb4_general_ci NOT NULL,
  `visi` text COLLATE utf8mb4_general_ci NOT NULL,
  `misi` text COLLATE utf8mb4_general_ci NOT NULL,
  `logo` text COLLATE utf8mb4_general_ci NOT NULL,
  `email` text COLLATE utf8mb4_general_ci NOT NULL,
  `nohp` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.website: ~0 rows (approximately)
DELETE FROM `website`;
INSERT INTO `website` (`id`, `namaweb`, `tentang`, `visi`, `misi`, `logo`, `email`, `nohp`) VALUES
	(1, 'Visit Cianjur', '<p><strong>Visit Cianjur</strong> adalah portal resmi pariwisata Cianjur yang menyediakan informasi terkini dan terpercaya tentang destinasi wisata, budaya, dan event di Cianjur.</p><p>Website ini juga mendukung pelaku wisata, mempromosikan atraksi lokal, serta memastikan transparansi informasi publik untuk masyarakat dan wisatawan.</p>', 'asdasdsaasdsad', '<ol><li>sadsadsadsad</li><li>adasdasda</li><li>dasdsads</li></ol>', '6JAq6jjFCgvlzIcne78Exu1NWDqe2BocX8TXoJx8.jpg', 'visitcianjur@gmail.com', '082273669900');

-- Dumping structure for table laravelpariwisata.wisata
CREATE TABLE IF NOT EXISTS `wisata` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kategori_id` bigint NOT NULL DEFAULT '0',
  `judul` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_general_ci NOT NULL,
  `jambuka` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `jamtutup` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `desa` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `kecamatan` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `lat` text COLLATE utf8mb4_general_ci NOT NULL,
  `lng` text COLLATE utf8mb4_general_ci NOT NULL,
  `hargatiket` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `thumbnail` text COLLATE utf8mb4_general_ci,
  `status` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.wisata: ~1 rows (approximately)
DELETE FROM `wisata`;
INSERT INTO `wisata` (`id`, `kategori_id`, `judul`, `deskripsi`, `jambuka`, `jamtutup`, `alamat`, `desa`, `kecamatan`, `lat`, `lng`, `hargatiket`, `thumbnail`, `status`) VALUES
	(4, 2, 'Wisata Air Terjun', '<p>sadadasdaafgrgnghnohfwafn hhfwfwhjefwojfwef</p><p>wefwefhweifhwofwehjfajwofjaweofijwaefaf</p><p>gfghfigrmwoifjwfmnsdfnoeifnofijijrfwe</p>', '07:00', '17:00', 'Jl. Jendral Sudirman, No. 44, Palembang', 'Suka Mundur', 'Kebon Jeruk', '-2.979316', '104.822976', '100000', 'POqjmkZ8T28tUxbgvyHSAMtgKG3OxKF2j1sheEPB.webp', 'Aktif');

-- Dumping structure for table laravelpariwisata.wisatafoto
CREATE TABLE IF NOT EXISTS `wisatafoto` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wisata_id` bigint NOT NULL DEFAULT '0',
  `foto` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table laravelpariwisata.wisatafoto: ~2 rows (approximately)
DELETE FROM `wisatafoto`;
INSERT INTO `wisatafoto` (`id`, `wisata_id`, `foto`) VALUES
	(6, 4, '3IfbkmTZChBErcmOj4Y3baLNcZOH5jlXPfnf3QEz.jpg'),
	(7, 4, '7lwFu5mHvim4gbSVtMdfVvBkj4qlZTlPr1BOsxsC.jpg');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
