<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PanelController;
use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', [HomeController::class, 'index']);

Route::controller(AuthController::class)->group(function () {
    Route::get('login', 'login');
    Route::post('loginproses', 'loginproses');
    Route::get('logout', 'logout');
});

Route::controller(HomeController::class)->group(function () {
    Route::get('tentang', 'tentang');
    Route::get('visimisi', 'visimisi');
    Route::get('strukturorganisasi', 'strukturorganisasi');
    Route::get('kategori/{id}', 'kategori');
    Route::get('wisatadetail/{id}', 'wisatadetail');
    Route::get('event', 'event');
    Route::get('eventdetail/{id}', 'eventdetail');
    Route::get('artikel', 'artikel');
    Route::get('artikeldetail/{id}', 'artikeldetail');
    Route::get('galeri', 'galeri');
    Route::get('pengumuman', 'pengumuman');
    Route::get('pengumumandetail/{id}', 'pengumumandetail');
});

Route::middleware(['auth'])->controller(PanelController::class)->group(function () {
    Route::get('panel', 'dashboard');

    // website
    Route::get('panel/website', 'website');
    Route::put('panel/websiteupdate', 'websiteupdate');

    // strukturorganisasi
    Route::get('panel/strukturorganisasi', 'strukturorganisasi');
    Route::post('panel/strukturorganisasisimpan', 'strukturorganisasisimpan');
    Route::get('panel/strukturorganisasiedit/{id}', 'strukturorganisasiedit');
    Route::put('panel/strukturorganisasiupdate/{id}', 'strukturorganisasiupdate');
    Route::delete('panel/strukturorganisasihapus/{id}', 'strukturorganisasihapus');

    // hero
    Route::get('panel/hero', 'hero');
    Route::post('panel/herosimpan', 'herosimpan');
    Route::get('panel/heroedit/{id}', 'heroedit');
    Route::put('panel/heroupdate/{id}', 'heroupdate');
    Route::delete('panel/herohapus/{id}', 'herohapus');

    // kategori
    Route::get('panel/kategori', 'kategori');
    Route::post('panel/kategorisimpan', 'kategorisimpan');
    Route::get('panel/kategoriedit/{id}', 'kategoriedit');
    Route::put('panel/kategoriupdate/{id}', 'kategoriupdate');
    Route::delete('panel/kategorihapus/{id}', 'kategorihapus');

    // wisata
    Route::get('panel/wisata', 'wisata');
    Route::get('panel/wisatatambah', 'wisatatambah');
    Route::post('panel/wisatasimpan', 'wisatasimpan');
    Route::get('panel/wisataedit/{id}', 'wisataedit');
    Route::post('panel/wisatafotosimpan/{id}', 'wisatafotosimpan');
    Route::delete('panel/wisatafotohapus/{id}', 'wisatafotohapus');
    Route::put('panel/wisataupdate/{id}', 'wisataupdate');
    Route::delete('panel/wisatahapus/{id}', 'wisatahapus');

    // event
    Route::get('panel/event', 'event');
    Route::get('panel/eventtambah', 'eventtambah');
    Route::post('panel/eventsimpan', 'eventsimpan');
    Route::get('panel/eventedit/{id}', 'eventedit');
    Route::put('panel/eventupdate/{id}', 'eventupdate');
    Route::delete('panel/eventhapus/{id}', 'eventhapus');

    // kategoriartikel
    Route::get('panel/kategoriartikel', 'kategoriartikel');
    Route::post('panel/kategoriartikelsimpan', 'kategoriartikelsimpan');
    Route::get('panel/kategoriartikeledit/{id}', 'kategoriartikeledit');
    Route::put('panel/kategoriartikelupdate/{id}', 'kategoriartikelupdate');
    Route::delete('panel/kategoriartikelhapus/{id}', 'kategoriartikelhapus');

    // artikel
    Route::get('panel/artikel', 'artikel');
    Route::get('panel/artikeltambah', 'artikeltambah');
    Route::post('panel/artikelsimpan', 'artikelsimpan');
    Route::get('panel/artikeledit/{id}', 'artikeledit');
    Route::put('panel/artikelupdate/{id}', 'artikelupdate');
    Route::delete('panel/artikelhapus/{id}', 'artikelhapus');

    // kategorigaleri
    Route::get('panel/kategorigaleri', 'kategorigaleri');
    Route::post('panel/kategorigalerisimpan', 'kategorigalerisimpan');
    Route::get('panel/kategorigaleriedit/{id}', 'kategorigaleriedit');
    Route::put('panel/kategorigaleriupdate/{id}', 'kategorigaleriupdate');
    Route::delete('panel/kategorigalerihapus/{id}', 'kategorigalerihapus');

    // galeri
    Route::get('panel/galeri', 'galeri');
    Route::get('panel/galeritambah', 'galeritambah');
    Route::post('panel/galerisimpan', 'galerisimpan');
    Route::get('panel/galeriedit/{id}', 'galeriedit');
    Route::put('panel/galeriupdate/{id}', 'galeriupdate');
    Route::delete('panel/galerihapus/{id}', 'galerihapus');

    // pengumuman
    Route::get('panel/pengumuman', 'pengumuman');
    Route::get('panel/pengumumantambah', 'pengumumantambah');
    Route::post('panel/pengumumansimpan', 'pengumumansimpan');
    Route::get('panel/pengumumanedit/{id}', 'pengumumanedit');
    Route::put('panel/pengumumanupdate/{id}', 'pengumumanupdate');
    Route::delete('panel/pengumumanhapus/{id}', 'pengumumanhapus');

    // profile
    Route::get('panel/profile', 'profile');
    Route::put('panel/profileupdate', 'profileupdate');
});
